package com.photobestselector.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.text.SimpleDateFormat
import java.util.Locale
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import java.util.Calendar
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import kotlin.math.abs
import kotlin.math.sqrt

private val Ink = Color(0xFF18324A)
private val Blue = Color(0xFF2686C9)
private val Green = Color(0xFF19A66A)
private val Pale = Color(0xFFF3FAFE)

private data class FaceLightingStats(
    val mean: Double,
    val lowerQuartile: Double,
    val shadowFraction: Double
)

private data class PhotoScore(
    val uri: Uri,
    val score: Int,
    val sharpness: Double,
    val brightness: Double,
    val faceCount: Int,
    val openEyes: Int,
    val groupNumber: Int,
    val isGroupBest: Boolean,
    val isFinalist: Boolean,
    val finalistRank: Int,
    val technicalRejected: Boolean,
    val explanation: String
)

private data class PhotoCandidate(
    val uri: Uri,
    val score: Int,
    val sharpness: Double,
    val brightness: Double,
    val faceCount: Int,
    val openEyes: Int,
    val timestampMs: Long?,
    val sceneHash: Long,
    val colorSignature: List<Float>,
    val faceCenters: List<Pair<Float, Float>>,
    val technicalRejected: Boolean,
    val explanation: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoBestSelectorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoBestSelectorApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var status by remember { mutableStateOf("Choose photos from your gallery to compare them.") }
    var analyzing by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<PhotoScore>>(emptyList()) }
    var preview by remember { mutableStateOf<Uri?>(null) }
    var previewItems by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var previewIndex by remember { mutableIntStateOf(0) }
    var language by remember { mutableStateOf("en") }
    var languageMenu by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var startDate by remember { mutableStateOf<Long?>(null) }
    var endDate by remember { mutableStateOf<Long?>(null) }
    var appliedStartDate by remember { mutableStateOf<Long?>(null) }
    var appliedEndDate by remember { mutableStateOf<Long?>(null) }
    var showStartDatePicker by remember { mutableStateOf(false) }
    var showEndDatePicker by remember { mutableStateOf(false) }
    var pendingAllPhotos by remember { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("photo_best_selector", android.content.Context.MODE_PRIVATE) }

    fun t(en: String, it: String, de: String, fr: String, es: String): String = when (language) {
        "it" -> it; "de" -> de; "fr" -> fr; "es" -> es; else -> en
    }

    val readImagesPermission = if (android.os.Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && pendingAllPhotos) {
            pendingAllPhotos = false
            scope.launch {
                val loaded = withContext(Dispatchers.IO) { loadCandidatePhotos(context, appliedStartDate, appliedEndDate) }
                photos = loaded
                results = emptyList()
                status = if (loaded.isNotEmpty()) "${loaded.size} photos loaded. Ready to analyze." else t("No photos found for this date range.", "Nessuna foto trovata per questo intervallo.", "Keine Fotos für diesen Zeitraum gefunden.", "Aucune photo trouvée pour cette période.", "No se encontraron fotos en este periodo.")
            }
        }
    }
    LaunchedEffect(Unit) {
        language = prefs.getString("language", "en") ?: "en"
        favorites = prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
    }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(200)
    ) { uris ->
        photos = uris
        results = emptyList()
        status = if (uris.isNotEmpty()) "${uris.size} photos selected. Ready to analyze." else t("No photos selected.", "Nessuna foto selezionata.", "Keine Fotos ausgewählt.", "Aucune photo sélectionnée.", "No se seleccionaron fotos.")
    }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, secondary = Green, background = Pale, surface = Color.White, onSurface = Ink)
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PhotoBestSelector", fontWeight = FontWeight.Bold, color = Ink)
                            Text("Find Your Perfect Shot.", fontSize = 12.sp, color = Blue)
                        }
                    },
                    actions = {
                        Box {
                            TextButton(onClick = { languageMenu = true }) { Text(language.uppercase(), color = Ink, fontWeight = FontWeight.Bold) }
                            DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                                listOf("en" to "English", "it" to "Italiano", "de" to "Deutsch", "fr" to "Français", "es" to "Español").forEach { (code, label) ->
                                    DropdownMenuItem(text = { Text(label) }, onClick = {
                                        language = code; prefs.edit().putString("language", code).apply(); languageMenu = false
                                    })
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE1F2FB)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📸", fontSize = 40.sp)
                        Text(t("Many photos. One winner.", "Tante foto. Uno scatto vincente.", "Viele Fotos. Ein Gewinner.", "Plusieurs photos. Une gagnante.", "Muchas fotos. Una ganadora."), color = Ink, fontWeight = FontWeight.Bold)
                        Text(t("All photos stay together on one screen.", "Tutte le foto restano in un'unica schermata.", "Alle Fotos bleiben auf einem Bildschirm.", "Toutes les photos restent sur un seul écran.", "Todas las fotos aparecen en una sola pantalla."), color = Ink.copy(alpha = .7f), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) { Text(t("CHOOSE PHOTOS", "SCEGLI FOTO", "FOTOS AUSWÄHLEN", "CHOISIR DES PHOTOS", "ELEGIR FOTOS"), fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        pendingAllPhotos = true
                        if (ContextCompat.checkSelfPermission(context, readImagesPermission) == PackageManager.PERMISSION_GRANTED) {
                            pendingAllPhotos = false
                            scope.launch {
                                val loaded = withContext(Dispatchers.IO) { loadCandidatePhotos(context, appliedStartDate, appliedEndDate) }
                                photos = loaded; results = emptyList()
                                status = if (loaded.isNotEmpty()) "${loaded.size} photos loaded. Ready to analyze." else t("No photos found for this date range.", "Nessuna foto trovata per questo intervallo.", "Keine Fotos für diesen Zeitraum gefunden.", "Aucune photo trouvée pour cette période.", "No se encontraron fotos en este periodo.")
                            }
                        } else permissionLauncher.launch(readImagesPermission)
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)
                ) { Text(t("SELECT ALL PHOTOS", "SELEZIONA TUTTE LE FOTO", "ALLE FOTOS AUSWÄHLEN", "SÉLECTIONNER TOUTES LES PHOTOS", "SELECCIONAR TODAS LAS FOTOS"), fontWeight = FontWeight.Bold) }

                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { showStartDatePicker = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text(startDate?.let { formatDate(it) } ?: t("FROM DATE", "DATA INIZIO", "STARTDATUM", "DATE DE DÉBUT", "FECHA INICIO"), fontSize = 11.sp)
                    }
                    OutlinedButton(onClick = { showEndDatePicker = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text(endDate?.let { formatDate(it) } ?: t("TO DATE", "DATA FINE", "ENDDATUM", "DATE DE FIN", "FECHA FIN"), fontSize = 11.sp)
                    }
                }
                if (startDate != null || endDate != null) {
                    TextButton(onClick = { startDate = null; endDate = null; appliedStartDate = null; appliedEndDate = null; photos = emptyList(); results = emptyList() }) {
                        Text(t("CLEAR DATE FILTER", "CANCELLA FILTRO DATA", "DATUMSFILTER LÖSCHEN", "EFFACER LE FILTRE DE DATE", "BORRAR FILTRO DE FECHA"), color = Blue, fontSize = 11.sp)
                    }
                }
                if (startDate != null || endDate != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            appliedStartDate = startDate
                            appliedEndDate = endDate
                            pendingAllPhotos = true
                            if (ContextCompat.checkSelfPermission(context, readImagesPermission) == PackageManager.PERMISSION_GRANTED) {
                                pendingAllPhotos = false
                                scope.launch {
                                    val loaded = withContext(Dispatchers.IO) { loadCandidatePhotos(context, appliedStartDate, appliedEndDate) }
                                    photos = loaded; results = emptyList()
                                    status = if (loaded.isNotEmpty()) "${loaded.size} photos loaded. Ready to analyze." else t("No photos found for this date range.", "Nessuna foto trovata per questo intervallo.", "Keine Fotos für diesen Zeitraum gefunden.", "Aucune photo trouvée pour cette période.", "No se encontraron fotos en este periodo.")
                                }
                            } else permissionLauncher.launch(readImagesPermission)
                        }, modifier = Modifier.weight(1f)) { Text(t("CONFIRM DATES", "CONFERMA DATE", "DATEN BESTÄTIGEN", "CONFIRMER LES DATES", "CONFIRMAR FECHAS"), fontSize = 10.sp) }
                        OutlinedButton(onClick = {
                            startDate = null; endDate = null; appliedStartDate = null; appliedEndDate = null
                            photos = emptyList(); results = emptyList()
                            status = t("Date selection cancelled.", "Selezione date annullata.", "Datumsauswahl abgebrochen.", "Sélection des dates annulée.", "Selección de fechas cancelada.")
                        }, modifier = Modifier.weight(1f)) { Text(t("CANCEL", "ANNULLA", "ABBRECHEN", "ANNULER", "CANCELAR"), fontSize = 10.sp) }
                    }
                }
                if (photos.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("${photos.size} ${t("photos selected", "foto selezionate", "Fotos ausgewählt", "photos sélectionnées", "fotos seleccionadas")}", color = Green, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(photos) { uri ->
                            Box(Modifier.size(76.dp)) {
                                AsyncImage(model = uri, contentDescription = "Selected photo",
                                    modifier = Modifier.fillMaxSize().clickable { previewItems = photos; previewIndex = photos.indexOf(uri); preview = uri },
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                IconButton(onClick = { photos = photos.filterNot { it == uri }; results = emptyList(); status = t("Photo excluded from selection.", "Foto esclusa dalla selezione.", "Foto aus Auswahl entfernt.", "Photo exclue de la sélection.", "Foto excluida de la selección.") },
                                    modifier = Modifier.align(Alignment.TopEnd).size(20.dp).background(Color.Black.copy(alpha = .78f), RoundedCornerShape(50))) {
                                    Text("×", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { photos = emptyList(); results = emptyList(); status = t("Selection cancelled.", "Selezione annullata.", "Auswahl abgebrochen.", "Sélection annulée.", "Selección cancelada.") },
                            modifier = Modifier.weight(1f)) { Text(t("CANCEL SELECTION", "ANNULLA SELEZIONE", "AUSWAHL ABBRECHEN", "ANNULER LA SÉLECTION", "CANCELAR SELECCIÓN"), fontSize = 10.sp) }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        enabled = !analyzing,
                        onClick = {
                            analyzing = true; results = emptyList()
                            status = t("Analyzing photos on this device...", "Analisi delle foto sul dispositivo...", "Fotos werden auf diesem Gerät analysiert...", "Analyse des photos sur cet appareil...", "Analizando fotos en este dispositivo...")
                            scope.launch {
                                try {
                                    val scored = withContext(Dispatchers.IO) { analyzePhotos(context, photos) }
                                    results = scored.sortedWith(compareBy<PhotoScore> { it.technicalRejected }.thenByDescending { it.score })
                                    status = if (scored.isEmpty())
                                        t("No matching photo sequences found. Only groups of 2 or more visually similar photos with capture times within 60 seconds are shown.", "Nessuna sequenza compatibile trovata. Vengono mostrate solo sequenze di almeno 2 foto visivamente simili, con orari di scatto entro 60 secondi.", "Keine passenden Fotoserien gefunden. Angezeigt werden nur Gruppen mit mindestens 2 visuell ähnlichen Fotos innerhalb von 60 Sekunden.", "Aucune séquence correspondante. Seuls les groupes d'au moins 2 photos visuellement similaires prises en moins de 60 secondes sont affichés.", "No se encontraron secuencias coincidentes. Solo se muestran grupos de al menos 2 fotos visualmente similares tomadas en menos de 60 segundos.")
                                    else t("Analysis complete.", "Analisi completata.", "Analyse abgeschlossen.", "Analyse terminée.", "Análisis completado.")
                                } catch (_: Exception) {
                                    status = t("Analysis failed. Please try again.", "Analisi non riuscita. Riprova.", "Analyse fehlgeschlagen. Bitte erneut versuchen.", "Échec de l'analyse. Réessayez.", "El análisis falló. Inténtalo de nuevo.")
                                } finally { analyzing = false }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Green)
                    ) {
                        if (analyzing) CircularProgressIndicator(modifier = Modifier.size(21.dp), color = Color.White, strokeWidth = 2.dp)
                        else Text(t("START ANALYSIS", "AVVIA ANALISI", "ANALYSE STARTEN", "LANCER L'ANALYSE", "INICIAR ANÁLISIS"), fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(status, color = Ink.copy(alpha = .72f), fontSize = 12.sp)
                if (results.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    val groupedResults = results.groupBy { it.groupNumber }.toSortedMap().filterValues { it.size >= 2 }
                    Text(t("PHOTO GROUPS — TAP TO ENLARGE", "GRUPPI DI FOTO — TOCCA PER INGRANDIRE", "FOTOGRUPPEN — ZUM VERGRÖSSERN TIPPEN", "GROUPES DE PHOTOS — TOUCHER POUR AGRANDIR", "GRUPOS DE FOTOS — TOCA PARA AMPLIAR"), color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    groupedResults.forEach { (groupNumber, groupItems) ->
                        Spacer(Modifier.height(10.dp))
                        val orderedGroup = groupItems.sortedWith(compareBy<PhotoScore> { !it.isGroupBest }.thenByDescending { it.score })
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDCEAF2))) {
                            Column(Modifier.fillMaxWidth().padding(8.dp)) {
                                Text("${t("GROUP", "GRUPPO", "GRUPPE", "GROUPE", "GRUPO")} $groupNumber • ${groupItems.size} ${t("photos", "foto", "Fotos", "photos", "fotos")}", color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Spacer(Modifier.height(7.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                    items(orderedGroup, key = { it.uri.toString() }) { item ->
                                        val key = item.uri.toString()
                                        val isFav = favorites.contains(key)
                                        Card(modifier = Modifier.width(142.dp), shape = RoundedCornerShape(14.dp),
                                            colors = CardDefaults.cardColors(containerColor = Color.White),
                                            border = androidx.compose.foundation.BorderStroke(if (item.isGroupBest) 2.dp else 1.dp, if (item.isGroupBest) Green else Color(0xFFDCEAF2))) {
                                            Column(Modifier.padding(7.dp)) {
                                                Box(Modifier.fillMaxWidth().height(112.dp)) {
                                                    AsyncImage(model = item.uri, contentDescription = "Photo in group",
                                                        modifier = Modifier.fillMaxSize().clickable { previewItems = orderedGroup.map { it.uri }; previewIndex = orderedGroup.indexOf(item); preview = item.uri },
                                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                                    IconButton(onClick = {
                                                        val updated = results.filterNot { it.uri == item.uri }
                                                        results = updated.groupBy { it.groupNumber }.values.filter { it.size >= 2 }.flatten()
                                                        photos = photos.filterNot { it == item.uri }
                                                    }, modifier = Modifier.align(Alignment.TopEnd).size(20.dp).background(Color.Black.copy(alpha = .78f), RoundedCornerShape(50))) {
                                                        Text("×", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                    }
                                                }
                                                Text(if (item.isGroupBest) t("BEST PHOTO", "FOTO MIGLIORE", "BESTES FOTO", "MEILLEURE PHOTO", "MEJOR FOTO") else t("ALTERNATIVE", "ALTERNATIVA", "ALTERNATIVE", "ALTERNATIVE", "ALTERNATIVA"),
                                                    color = if (item.isGroupBest) Green else Blue, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                                                Text("${item.score}/100", color = Ink, fontWeight = FontWeight.Bold)
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(onClick = {
                                                        favorites = if (isFav) favorites - key else favorites + key
                                                        prefs.edit().putStringSet("favorites", favorites).apply()
                                                    }, modifier = Modifier.size(30.dp)) {
                                                        Icon(if (isFav) Icons.Default.Star else Icons.Default.StarBorder, contentDescription = "Favorite", tint = if (isFav) Color(0xFFE0A000) else Ink)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Text(t("The app checks technical quality and each detected face separately. Composition, posture and emotional impact still need your visual final check. Originals are never deleted.", "L'app valuta qualità tecnica e ogni volto separatamente. Composizione, postura ed emozione richiedono ancora il tuo controllo visivo. Gli originali non vengono mai eliminati.", "Die App prüft technische Qualität und jedes Gesicht einzeln. Bildaufbau, Haltung und Ausdruck brauchen weiterhin deine Sichtprüfung. Originale werden nie gelöscht.", "L'application évalue la qualité technique et chaque visage séparément. La composition, la posture et l'émotion nécessitent encore votre vérification. Les originaux ne sont jamais supprimés.", "La app evalúa la calidad técnica y cada rostro por separado. La composición, postura y emoción aún requieren tu revisión visual. Los originales nunca se eliminan."), color = Ink.copy(alpha = .6f), fontSize = 11.sp, lineHeight = 15.sp)
                }
                Spacer(Modifier.height(16.dp))
                Text("Private by design • Original photos stay untouched", color = Ink.copy(alpha = .55f), fontSize = 10.sp)
                Spacer(Modifier.height(16.dp))
            }
        }
        if (showStartDatePicker) {
            val state = rememberDatePickerState(initialSelectedDateMillis = startDate ?: System.currentTimeMillis())
            DatePickerDialog(onDismissRequest = { showStartDatePicker = false }, confirmButton = {
                TextButton(onClick = { startDate = startOfDay(state.selectedDateMillis); if (endDate != null && startDate!! > endDate!!) endDate = null; showStartDatePicker = false }) { Text(t("OK", "OK", "OK", "OK", "OK")) }
            }, dismissButton = { TextButton(onClick = { showStartDatePicker = false }) { Text(t("CANCEL", "ANNULLA", "ABBRECHEN", "ANNULER", "CANCELAR")) } }) { DatePicker(state) }
        }
        if (showEndDatePicker) {
            val state = rememberDatePickerState(initialSelectedDateMillis = endDate ?: System.currentTimeMillis())
            DatePickerDialog(onDismissRequest = { showEndDatePicker = false }, confirmButton = {
                TextButton(onClick = { endDate = endOfDay(state.selectedDateMillis); if (startDate != null && endDate!! < startDate!!) startDate = null; showEndDatePicker = false }) { Text(t("OK", "OK", "OK", "OK", "OK")) }
            }, dismissButton = { TextButton(onClick = { showEndDatePicker = false }) { Text(t("CANCEL", "ANNULLA", "ABBRECHEN", "ANNULER", "CANCELAR")) } }) { DatePicker(state) }
        }

        if (preview != null) {
            var zoom by remember(preview) { mutableFloatStateOf(1f) }
            var pan by remember(preview) { mutableStateOf(Offset.Zero) }
            val transformState = rememberTransformableState { zoomChange, panChange, _ ->
                zoom = (zoom * zoomChange).coerceIn(1f, 5f)
                pan = if (zoom <= 1f) Offset.Zero else pan + panChange
            }
            androidx.compose.ui.window.Dialog(onDismissRequest = { preview = null }) {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.Black)) {
                    Column(Modifier.fillMaxWidth().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${previewIndex + 1} / ${previewItems.size}", color = Color.White, fontWeight = FontWeight.Bold)
                        AsyncImage(model = preview, contentDescription = "Enlarged photo",
                            modifier = Modifier.fillMaxWidth().heightIn(max = 560.dp)
                                .graphicsLayer(scaleX = zoom, scaleY = zoom, translationX = pan.x, translationY = pan.y)
                                .transformable(transformState)
                                .pointerInput(preview, previewIndex, zoom) {
                                    var dragTotal = 0f
                                    detectHorizontalDragGestures(onHorizontalDrag = { change, dragAmount ->
                                        dragTotal += dragAmount
                                        change.consume()
                                    }, onDragEnd = {
                                        if (zoom <= 1.05f && kotlin.math.abs(dragTotal) > 65f && previewItems.isNotEmpty()) {
                                            val next = (previewIndex + if (dragTotal < 0) 1 else -1).coerceIn(0, previewItems.lastIndex)
                                            previewIndex = next; preview = previewItems[next]; zoom = 1f; pan = Offset.Zero
                                        }
                                        dragTotal = 0f
                                    })
                                },
                            contentScale = androidx.compose.ui.layout.ContentScale.Fit)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            TextButton(enabled = previewIndex > 0, onClick = { previewIndex--; preview = previewItems[previewIndex]; zoom = 1f; pan = Offset.Zero }) { Text("‹", color = Color.White, fontSize = 24.sp) }
                            TextButton(onClick = { zoom = 1f; pan = Offset.Zero }) { Text(t("RESET ZOOM", "REIMPOSTA ZOOM", "ZOOM ZURÜCKSETZEN", "RÉINITIALISER", "RESTABLECER ZOOM"), color = Color.White, fontSize = 10.sp) }
                            TextButton(enabled = previewIndex < previewItems.lastIndex, onClick = { previewIndex++; preview = previewItems[previewIndex]; zoom = 1f; pan = Offset.Zero }) { Text("›", color = Color.White, fontSize = 24.sp) }
                        }
                        TextButton(onClick = { preview = null }) { Text(t("CLOSE", "CHIUDI", "SCHLIESSEN", "FERMER", "CERRAR"), color = Color.White) }
                    }
                }
            }
        }
    }
}

private fun startOfDay(millis: Long?): Long? = millis?.let { Calendar.getInstance().apply { timeInMillis = it; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis }

private fun endOfDay(millis: Long?): Long? = millis?.let { Calendar.getInstance().apply { timeInMillis = it; set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }.timeInMillis }

private fun formatDate(millis: Long): String = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(java.util.Date(millis))

private fun loadCandidatePhotos(context: android.content.Context, startDate: Long?, endDate: Long?): List<Uri> {
    val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN, MediaStore.Images.Media.DATE_ADDED)
    val output = mutableListOf<Pair<Long, Uri>>()
    context.contentResolver.query(collection, projection, null, null, MediaStore.Images.Media.DATE_TAKEN + " DESC")?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val takenCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
        val addedCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_ADDED)
        while (cursor.moveToNext()) {
            val id = cursor.getLong(idCol)
            val taken = if (takenCol >= 0 && !cursor.isNull(takenCol)) cursor.getLong(takenCol) else 0L
            val added = if (addedCol >= 0 && !cursor.isNull(addedCol)) cursor.getLong(addedCol) * 1000L else 0L
            val timestamp = if (taken > 0) taken else added
            val inRange = (startDate == null || timestamp >= startDate) && (endDate == null || timestamp <= endDate)
            if (inRange) output.add(timestamp to Uri.withAppendedPath(collection, id.toString()))
        }
    }
    val sorted = output.sortedBy { it.first }
    if (sorted.size < 2) return emptyList()

    // Only keep photos that have another capture within 60 seconds.
    // This prevents isolated photos from being loaded into the selection strip.
    val candidate = sorted.filterIndexed { index, item ->
        val previousGap = if (index > 0) item.first - sorted[index - 1].first else Long.MAX_VALUE
        val nextGap = if (index < sorted.lastIndex) sorted[index + 1].first - item.first else Long.MAX_VALUE
        previousGap <= 60_000L || nextGap <= 60_000L
    }
    return candidate.sortedByDescending { it.first }.map { it.second }
}

private fun analyzePhotos(context: android.content.Context, uris: List<Uri>): List<PhotoScore> {
    val options = FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
        .build()
    val detector = FaceDetection.getClient(options)
    try {
        val candidates = uris.mapNotNull { uri ->
            val bitmap = loadBitmap(context.contentResolver.openInputStream(uri)) ?: return@mapNotNull null
            try {
                val faces = Tasks.await(detector.process(InputImage.fromBitmap(bitmap, 0)))
                val globalSharpness = calculateSharpness(bitmap)
                val globalBrightness = calculateBrightness(bitmap)
                val faceScores = faces.map { face ->
                    val box = face.boundingBox
                    val padX = (box.width() * 0.12f).toInt()
                    val padY = (box.height() * 0.12f).toInt()
                    val left = (box.left - padX).coerceIn(0, bitmap.width - 1)
                    val top = (box.top - padY).coerceIn(0, bitmap.height - 1)
                    val right = (box.right + padX).coerceIn(left + 1, bitmap.width)
                    val bottom = (box.bottom + padY).coerceIn(top + 1, bitmap.height)
                    val crop = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
                    val faceLighting = calculateFaceLighting(crop)
                    val faceSharp = calculateSharpness(crop)
                    crop.recycle()

                    val leftEye = face.leftEyeOpenProbability
                    val rightEye = face.rightEyeOpenProbability
                    val eyeScore = when {
                        leftEye == null && rightEye == null -> 65.0
                        leftEye != null && rightEye != null -> {
                            val weakerEye = minOf(leftEye, rightEye)
                            (weakerEye * 100.0).coerceIn(0.0, 100.0)
                        }
                        else -> ((leftEye ?: rightEye ?: 0.5f) * 85.0).coerceIn(0.0, 85.0)
                    }
                    // Face illumination is measured inside the face crop, not from the whole photo.
                    // The lower quartile and dark-pixel ratio help detect a face partly lost in shadow.
                    val meanLightScore = ((faceLighting.mean - 0.16) / 0.34 * 100.0).coerceIn(0.0, 100.0)
                    val lowerLightScore = ((faceLighting.lowerQuartile - 0.10) / 0.30 * 100.0).coerceIn(0.0, 100.0)
                    val shadowScore = (100.0 - faceLighting.shadowFraction * 190.0).coerceIn(0.0, 100.0)
                    val lightScore = (meanLightScore * 0.45 + lowerLightScore * 0.30 + shadowScore * 0.25).coerceIn(0.0, 100.0)
                    val sharpFaceScore = (sqrt(faceSharp.coerceAtLeast(0.0)) / 12.0 * 100.0).coerceIn(0.0, 100.0)
                    val smile = face.smilingProbability
                    // A natural/neutral expression remains valid; a detected smile is a small bonus only.
                    val expressionScore = if (smile == null) 75.0 else (75.0 + smile * 25.0).coerceIn(75.0, 100.0)
                    eyeScore * 0.35 + lightScore * 0.35 + sharpFaceScore * 0.20 + expressionScore * 0.10
                }
                val openEyes = faces.count { face ->
                    val l = face.leftEyeOpenProbability
                    val r = face.rightEyeOpenProbability
                    (l == null && r == null) || ((l ?: 0f) >= 0.45f && (r ?: 0f) >= 0.45f)
                }
                val globalSharpScore = (sqrt(globalSharpness.coerceAtLeast(0.0)) / 18.0 * 100.0).coerceIn(0.0, 100.0)
                val globalLightScore = (100.0 - abs(globalBrightness - 0.52) * 150.0).coerceIn(0.0, 100.0)
                val clippedFraction = calculateClippedFraction(bitmap)
                val exposurePenalty = when {
                    globalBrightness < 0.075 || globalBrightness > 0.94 -> 28.0
                    globalBrightness < 0.12 || globalBrightness > 0.88 -> 16.0
                    else -> 0.0
                } + (clippedFraction * 55.0).coerceAtMost(22.0)
                val blurPenalty = if (globalSharpScore < 18.0) 24.0 else if (globalSharpScore < 30.0) 12.0 else 0.0
                val closedEyeFaces = faces.count { face ->
                    val l = face.leftEyeOpenProbability
                    val r = face.rightEyeOpenProbability
                    l != null && r != null && l < 0.22f && r < 0.22f
                }
                val technicalRejected = globalSharpScore < 12.0 ||
                    globalBrightness < 0.045 || globalBrightness > 0.97 ||
                    (clippedFraction > 0.48 && (globalBrightness < 0.12 || globalBrightness > 0.88)) ||
                    (faces.isNotEmpty() && closedEyeFaces == faces.size)
                val overall = if (faceScores.isEmpty()) {
                    (globalSharpScore * 0.55 + globalLightScore * 0.45 - exposurePenalty - blurPenalty - if (technicalRejected) 35.0 else 0.0).coerceIn(0.0, 100.0)
                } else {
                    val averageFaces = faceScores.average()
                    val weakestFace = faceScores.minOrNull() ?: averageFaces
                    // Group photos are judged by everyone, not just the average: the weakest face
                    // receives half of the face-quality weight and very poor faces are penalized.
                    val groupFaces = averageFaces * 0.50 + weakestFace * 0.50
                    val severeSingleFacePenalty = when {
                        weakestFace < 30.0 -> (30.0 - weakestFace) * 0.90
                        weakestFace < 50.0 -> (50.0 - weakestFace) * 0.45
                        else -> 0.0
                    }
                    (globalSharpScore * 0.10 + globalLightScore * 0.05 + groupFaces * 0.85 - severeSingleFacePenalty - exposurePenalty - blurPenalty - if (technicalRejected) 35.0 else 0.0).coerceIn(0.0, 100.0)
                }
                val details = buildList {
                    add("${faces.size} faces detected")
                    if (faces.isNotEmpty()) add("$openEyes/${faces.size} faces with open/uncertain eyes")
                    add(if (globalSharpScore >= 60) "good overall sharpness" else "limited overall sharpness")
                    if (faceScores.isNotEmpty() && (faceScores.minOrNull() ?: 100.0) < 55.0) add("one face has weak lighting, focus or eyes")
                    add(if (globalLightScore >= 60) "balanced overall light" else "challenging overall light")
                    if (exposurePenalty > 12.0) add("technical warning: exposure/clipped highlights")
                    if (blurPenalty > 0.0) add("technical warning: possible blur")
                    if (technicalRejected) add("strong technical rejection flag")
                    if (faceScores.isNotEmpty() && (faceScores.minOrNull() ?: 100.0) < 45.0) add("reject from top shortlist: one face needs attention")
                }.joinToString(" • ")
                PhotoCandidate(
                    uri = uri,
                    score = overall.toInt().coerceIn(0, 100),
                    sharpness = globalSharpness,
                    brightness = globalBrightness,
                    faceCount = faces.size,
                    openEyes = openEyes,
                    timestampMs = readCaptureTime(context, uri),
                    sceneHash = calculateSceneHash(bitmap),
                    colorSignature = calculateColorSignature(bitmap),
                    faceCenters = faces.map { face ->
                        Pair(face.boundingBox.centerX().toFloat() / bitmap.width, face.boundingBox.centerY().toFloat() / bitmap.height)
                    }.sortedBy { it.first },
                    technicalRejected = technicalRejected,
                    explanation = details
                )
            } finally {
                bitmap.recycle()
            }
        }

        // Conservative sequence detection: require real capture timestamps, a <=60s
        // gap between consecutive shots, and visual similarity to both the previous
        // shot and the sequence anchor. Single photos are deliberately discarded.
        val sorted = candidates.filter { it.timestampMs != null }
            .sortedBy { it.timestampMs!! }
        val rawGroups = mutableListOf<MutableList<PhotoCandidate>>()
        for (candidate in sorted) {
            val current = rawGroups.lastOrNull()
            val previous = current?.lastOrNull()
            val anchor = current?.firstOrNull()
            val adjacentTime = previous?.timestampMs?.let { candidate.timestampMs!! - it }
            val joinsCurrent = current != null && previous != null && anchor != null &&
                adjacentTime != null && adjacentTime in 0L..60_000L &&
                isVisuallySimilar(candidate, previous) &&
                isVisuallySimilar(candidate, anchor)
            if (joinsCurrent) current!!.add(candidate)
            else rawGroups.add(mutableListOf(candidate))
        }
        val validGroups = rawGroups.filter { it.size >= 2 }
        return validGroups.flatMapIndexed { groupIndex, group ->
            val ranked = group.sortedWith(compareBy<PhotoCandidate> { it.technicalRejected }.thenByDescending { it.score })
            val winner = ranked.firstOrNull { !it.technicalRejected } ?: ranked.firstOrNull()
            ranked.mapIndexed { rankIndex, item ->
                PhotoScore(item.uri, item.score, item.sharpness, item.brightness, item.faceCount,
                    item.openEyes, groupIndex + 1, item.uri == winner?.uri,
                    item.uri == winner?.uri && !item.technicalRejected,
                    rankIndex + 1, item.technicalRejected, item.explanation)
            }
        }
    } finally {
        detector.close()
    }
}

private fun readCaptureTime(context: android.content.Context, uri: Uri): Long? {
    val mediaStoreTime = try {
        context.contentResolver.query(uri, arrayOf(MediaStore.Images.Media.DATE_TAKEN), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
                if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index).takeIf { it > 0L } else null
            } else null
        }
    } catch (_: Exception) { null }
    if (mediaStoreTime != null) return mediaStoreTime
    return try {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val exif = ExifInterface(stream)
            val date = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) ?: return@use null
            val offset = exif.getAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL)
            val parser = if (!offset.isNullOrBlank()) SimpleDateFormat("yyyy:MM:dd HH:mm:ssXXX", Locale.US)
                else SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
            parser.parse(if (!offset.isNullOrBlank()) date + offset else date)?.time
        }
    } catch (_: Exception) { null }
}

private fun isVisuallySimilar(a: PhotoCandidate, b: PhotoCandidate): Boolean {
    if (a.faceCount != b.faceCount) return false
    if (!similarFaceLayout(a.faceCenters, b.faceCenters)) return false
    val hashDistance = java.lang.Long.bitCount(a.sceneHash xor b.sceneHash)
    val colorDistance = colorHistogramDistance(a.colorSignature, b.colorSignature)
    return if (a.faceCount == 0) {
        // No faces: demand a much closer match, so nearby but unrelated scenes
        // are not merged merely because both contain no detected people.
        hashDistance <= 8 && colorDistance <= 0.30
    } else {
        hashDistance <= 13 && colorDistance <= 0.55
    }
}

private fun colorHistogramDistance(a: List<Float>, b: List<Float>): Double {
    if (a.size != b.size || a.isEmpty()) return Double.MAX_VALUE
    return a.indices.sumOf { kotlin.math.abs(a[it].toDouble() - b[it].toDouble()) } / 6.0
}

private fun calculateColorSignature(bitmap: Bitmap): List<Float> {
    val sample = Bitmap.createScaledBitmap(bitmap, 48, 48, true)
    val histogram = FloatArray(24)
    for (y in 0 until sample.height) for (x in 0 until sample.width) {
        val pixel = sample.getPixel(x, y)
        histogram[((pixel shr 16 and 0xff) * 8) / 256] += 1f
        histogram[8 + (((pixel shr 8 and 0xff) * 8) / 256)] += 1f
        histogram[16 + (((pixel and 0xff) * 8) / 256)] += 1f
    }
    sample.recycle()
    val total = (48 * 48).toFloat()
    return histogram.map { it / total }
}

private fun similarFaceLayout(a: List<Pair<Float, Float>>, b: List<Pair<Float, Float>>): Boolean {
    if (a.size != b.size) return false
    if (a.isEmpty()) return true
    return a.zip(b).all { (left, right) ->
        val dx = left.first - right.first
        val dy = left.second - right.second
        dx * dx + dy * dy <= 0.22f * 0.22f
    }
}

private fun calculateSceneHash(bitmap: Bitmap): Long {
    val sample = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
    val gray = IntArray(9 * 8)
    for (y in 0 until 8) for (x in 0 until 9) {
        val p = sample.getPixel(x, y)
        val r = (p shr 16 and 0xff)
        val g = (p shr 8 and 0xff)
        val b = (p and 0xff)
        gray[y * 9 + x] = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
    }
    sample.recycle()
    var hash = 0L
    var bit = 0
    for (y in 0 until 8) for (x in 0 until 8) {
        if (gray[y * 9 + x] > gray[y * 9 + x + 1]) hash = hash or (1L shl bit)
        bit++
    }
    return hash
}

private fun loadBitmap(stream: InputStream?): Bitmap? {
    if (stream == null) return null
    return stream.use { input ->
        val bytes = input.readBytes()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }
}


private fun calculateFaceLighting(bitmap: Bitmap): FaceLightingStats {
    // Ignore a narrow border around the detector box, where hair and background can distort
    // the measurement. Sample the central face area and inspect its darker quarter as well.
    val left = (bitmap.width * 0.12f).toInt().coerceIn(0, bitmap.width - 1)
    val top = (bitmap.height * 0.12f).toInt().coerceIn(0, bitmap.height - 1)
    val right = (bitmap.width * 0.88f).toInt().coerceIn(left + 1, bitmap.width)
    val bottom = (bitmap.height * 0.88f).toInt().coerceIn(top + 1, bitmap.height)
    val stepX = ((right - left) / 48).coerceAtLeast(1)
    val stepY = ((bottom - top) / 48).coerceAtLeast(1)
    val samples = ArrayList<Double>()
    for (y in top until bottom step stepY) {
        for (x in left until right step stepX) {
            val p = bitmap.getPixel(x, y)
            val r = (p shr 16 and 0xff) / 255.0
            val g = (p shr 8 and 0xff) / 255.0
            val b = (p and 0xff) / 255.0
            samples.add(0.2126 * r + 0.7152 * g + 0.0722 * b)
        }
    }
    if (samples.isEmpty()) return FaceLightingStats(0.5, 0.35, 0.0)
    samples.sort()
    val mean = samples.average()
    val lowerQuartile = samples[(samples.size * 0.25).toInt().coerceIn(0, samples.lastIndex)]
    val shadowFraction = samples.count { it < 0.18 }.toDouble() / samples.size
    return FaceLightingStats(mean, lowerQuartile, shadowFraction)
}

private fun calculateClippedFraction(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 100).coerceAtLeast(1)
    val stepY = (bitmap.height / 100).coerceAtLeast(1)
    var clipped = 0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16) and 0xff
            val g = (pixel shr 8) and 0xff
            val b = pixel and 0xff
            val luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
            if (luminance < 12.0 || luminance > 248.0) clipped++
            count++
        }
    }
    return if (count == 0) 0.0 else clipped.toDouble() / count
}

private fun calculateBrightness(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 80).coerceAtLeast(1)
    val stepY = (bitmap.height / 80).coerceAtLeast(1)
    var sum = 0.0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16 and 0xff) / 255.0
            val g = (pixel shr 8 and 0xff) / 255.0
            val b = (pixel and 0xff) / 255.0
            sum += 0.2126 * r + 0.7152 * g + 0.0722 * b
            count++
        }
    }
    return if (count == 0) 0.5 else sum / count
}

private fun calculateSharpness(bitmap: Bitmap): Double {
    val scale = minOf(1.0, 240.0 / maxOf(bitmap.width, bitmap.height))
    val w = (bitmap.width * scale).toInt().coerceAtLeast(3)
    val h = (bitmap.height * scale).toInt().coerceAtLeast(3)
    val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
    val values = DoubleArray(w * h)
    for (y in 0 until h) for (x in 0 until w) {
        val p = small.getPixel(x, y)
        val r = (p shr 16 and 0xff).toDouble()
        val g = (p shr 8 and 0xff).toDouble()
        val b = (p and 0xff).toDouble()
        values[y * w + x] = 0.299 * r + 0.587 * g + 0.114 * b
    }
    var sum = 0.0
    var sumSq = 0.0
    var count = 0
    for (y in 1 until h - 1) for (x in 1 until w - 1) {
        val i = y * w + x
        val lap = values[i - w] + values[i - 1] - 4 * values[i] + values[i + 1] + values[i + w]
        sum += lap
        sumSq += lap * lap
        count++
    }
    small.recycle()
    if (count == 0) return 0.0
    val mean = sum / count
    return (sumSq / count - mean * mean).coerceAtLeast(0.0)
}

@Composable
private fun ChoiceCard(
    title: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    selected: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) Blue else Color(0xFFDCEAF2)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFEAF6FC), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Ink.copy(alpha = .62f), fontSize = 11.sp)
            }
            RadioButton(selected = selected, onClick = onClick)
        }
    }
}
