package com.photobestselector.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.text.SimpleDateFormat
import java.util.Locale
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import java.util.Calendar
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.math.max

private val Ink = Color(0xFF18324A)
private val Blue = Color(0xFF2686C9)
private val Green = Color(0xFF19A66A)
private val Pale = Color(0xFFF3FAFE)

private data class FaceLightingStats(
    val mean: Double,
    val lowerQuartile: Double,
    val shadowFraction: Double
)

private data class PhotoScore(
    val uri: Uri,
    val score: Int,
    val sharpness: Double,
    val brightness: Double,
    val faceCount: Int,
    val openEyes: Int,
    val groupNumber: Int,
    val isGroupBest: Boolean,
    val isFinalist: Boolean,
    val finalistRank: Int,
    val technicalRejected: Boolean,
    val explanation: String
)

private data class PhotoCandidate(
    val uri: Uri,
    val score: Int,
    val sharpness: Double,
    val brightness: Double,
    val faceCount: Int,
    val openEyes: Int,
    val timestampMs: Long?,
    val sceneHash: Long,
    val faceCenters: List<Pair<Float, Float>>,
    val technicalRejected: Boolean,
    val explanation: String
)

private data class PhotoGroup(
    val number: Int,
    val photos: List<Uri>,
    val representative: Uri
)

private data class TrashRequestState(
    val uris: List<Uri>,
    val groupNumber: Int
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoBestSelectorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoBestSelectorApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var groups by remember { mutableStateOf<List<PhotoGroup>>(emptyList()) }
    var results by remember { mutableStateOf<List<PhotoScore>>(emptyList()) }
    var status by remember { mutableStateOf("Choose photos from your gallery to compare them.") }
    var analyzing by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("en") }
    var languageMenu by remember { mutableStateOf(false) }
    var startDate by remember { mutableStateOf<Long?>(null) }
    var endDate by remember { mutableStateOf<Long?>(null) }
    var showStartDatePicker by remember { mutableStateOf(false) }
    var showEndDatePicker by remember { mutableStateOf(false) }
    var previewGroup by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var previewIndex by remember { mutableIntStateOf(0) }
    var showChoiceGroup by remember { mutableStateOf<Int?>(null) }
    var showFolderGroup by remember { mutableStateOf<Int?>(null) }
    var selectedToKeep by remember { mutableStateOf<Map<Int, Set<String>>>(emptyMap()) }
    var trashRequest by remember { mutableStateOf<TrashRequestState?>(null) }
    val prefs = remember { context.getSharedPreferences("photo_best_selector", android.content.Context.MODE_PRIVATE) }

    fun t(en: String, it: String, de: String, fr: String, es: String): String = when (language) {
        "it" -> it; "de" -> de; "fr" -> fr; "es" -> es; else -> en
    }

    fun openPreview(list: List<Uri>, index: Int = 0) {
        previewGroup = list
        previewIndex = index.coerceIn(0, (list.size - 1).coerceAtLeast(0))
    }

    suspend fun loadAndGroup(list: List<Uri>) {
        val grouped = withContext(Dispatchers.IO) { buildVisualGroups(context, list) }
        groups = grouped
        photos = grouped.flatMap { it.photos }
        results = emptyList()
        status = if (photos.isNotEmpty()) "${photos.size} candidate photos in ${groups.size} groups." else t("No valid photo groups found.", "Nessun gruppo valido trovato.", "Keine gültigen Fotogruppen gefunden.", "Aucun groupe valide trouvé.", "No se encontraron grupos válidos.")
    }

    LaunchedEffect(Unit) { language = prefs.getString("language", "en") ?: "en" }

    val readImagesPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            scope.launch {
                val loaded = withContext(Dispatchers.IO) { loadCandidatePhotos(context, startDate, endDate) }
                loadAndGroup(loaded)
            }
        }
    }
    val trashLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val pending = trashRequest
        if (result.resultCode == android.app.Activity.RESULT_OK && pending != null) {
            val removed = pending.uris.toSet()
            groups = groups.mapNotNull { g ->
                val remaining = g.photos.filterNot { removed.contains(it) }
                if (remaining.size >= 2) g.copy(photos = remaining, representative = remaining.first()) else null
            }.mapIndexed { i, g -> g.copy(number = i + 1) }
            photos = groups.flatMap { it.photos }
            results = results.filterNot { removed.contains(it.uri) }.map { r ->
                val newNumber = groups.indexOfFirst { g -> g.photos.contains(r.uri) } + 1
                r.copy(groupNumber = newNumber)
            }.filter { it.groupNumber > 0 }
            status = t("Selected photos moved to Android Trash.", "Le foto selezionate sono state spostate nel Cestino Android.", "Die ausgewählten Fotos wurden in den Android-Papierkorb verschoben.", "Les photos sélectionnées ont été déplacées vers la corbeille Android.", "Las fotos seleccionadas se han movido a la Papelera de Android.")
        }
        trashRequest = null
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(200)) { uris ->
        if (uris.isNotEmpty()) scope.launch { loadAndGroup(uris) }
        else status = t("No photos selected.", "Nessuna foto selezionata.", "Keine Fotos ausgewählt.", "Aucune photo sélectionnée.", "No se seleccionaron fotos.")
    }

    fun requestTrash(uris: List<Uri>, groupNumber: Int) {
        val unique = uris.distinct()
        if (unique.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 30) {
            trashRequest = TrashRequestState(unique, groupNumber)
        } else {
            status = t(
                "Android 10 does not provide the standard system Trash API. The photos were not deleted.",
                "Android 10 non offre il Cestino di sistema standard. Le foto non sono state eliminate.",
                "Android 10 bietet keine standardmäßige System-Papierkorb-API. Die Fotos wurden nicht gelöscht.",
                "Android 10 ne fournit pas l'API standard de corbeille système. Les photos n'ont pas été supprimées.",
                "Android 10 no ofrece la API estándar de Papelera del sistema. Las fotos no se han eliminado."
            )
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Green, background = Pale, surface = Color.White, onSurface = Ink)) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = { Column { Text("PhotoBestSelector", fontWeight = FontWeight.Bold, color = Ink); Text("Find Your Perfect Shot.", fontSize = 12.sp, color = Blue) } },
                    actions = { Box { TextButton(onClick = { languageMenu = true }) { Text(language.uppercase(), color = Ink, fontWeight = FontWeight.Bold) }; DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) { listOf("en" to "English", "it" to "Italiano", "de" to "Deutsch", "fr" to "Français", "es" to "Español").forEach { (code,label) -> DropdownMenuItem(text={Text(label)}, onClick={ language=code; prefs.edit().putString("language",code).apply(); languageMenu=false }) } } } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal=16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Spacer(Modifier.height(12.dp))
                Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFE1F2FB)), shape=RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                        Text("📸", fontSize=40.sp)
                        Text(t("Many photos. One winner.","Tante foto. Uno scatto vincente.","Viele Fotos. Ein Gewinner.","Plusieurs photos. Une gagnante.","Muchas fotos. Una ganadora."),color=Ink,fontWeight=FontWeight.Bold)
                        Text(t("Only visually similar sequences are grouped.","Vengono raggruppate solo sequenze visivamente simili.","Nur visuell ähnliche Serien werden gruppiert.","Seules les séquences visuellement similaires sont regroupées.","Solo se agrupan secuencias visualmente similares."),color=Ink.copy(alpha=.7f),fontSize=12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(onClick={picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))},modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text(t("CHOOSE PHOTOS","SCEGLI FOTO","FOTOS AUSWÄHLEN","CHOISIR DES PHOTOS","ELEGIR FOTOS"),fontWeight=FontWeight.Bold)}
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick={
                    if(ContextCompat.checkSelfPermission(context,readImagesPermission)==PackageManager.PERMISSION_GRANTED) scope.launch { val loaded=withContext(Dispatchers.IO){loadCandidatePhotos(context,startDate,endDate)}; loadAndGroup(loaded) }
                    else permissionLauncher.launch(readImagesPermission)
                },modifier=Modifier.fillMaxWidth().height(50.dp),shape=RoundedCornerShape(16.dp)){Text(t("LOAD PHOTOS FROM DATES","CARICA FOTO DALLE DATE","FOTOS NACH DATUM LADEN","CHARGER LES PHOTOS PAR DATE","CARGAR FOTOS POR FECHA"),fontWeight=FontWeight.Bold)}
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton(onClick={showStartDatePicker=true},modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp)){Text(startDate?.let{formatDate(it)}?:t("FROM DATE","DATA INIZIO","STARTDATUM","DATE DE DÉBUT","FECHA INICIO"),fontSize=11.sp)}
                    OutlinedButton(onClick={showEndDatePicker=true},modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp)){Text(endDate?.let{formatDate(it)}?:t("TO DATE","DATA FINE","ENDDATUM","DATE DE FIN","FECHA FIN"),fontSize=11.sp)}
                }
                if(startDate!=null||endDate!=null) TextButton(onClick={startDate=null;endDate=null}){Text(t("CLEAR DATE FILTER","CANCELLA FILTRO DATA","DATUMSFILTER LÖSCHEN","EFFACER LE FILTRE DE DATE","BORRAR FILTRO DE FECHA"),color=Blue,fontSize=11.sp)}

                if(groups.isNotEmpty() && results.isEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text(t("PHOTO GROUPS","GRUPPI FOTO","FOTOGRUPPEN","GROUPES DE PHOTOS","GRUPOS DE FOTOS"),color=Ink,fontWeight=FontWeight.Bold,fontSize=14.sp)
                    Text(t("Tap a folder to see its thumbnails.","Tocca una cartella per vedere le miniature.","Tippe auf einen Ordner für die Miniaturen.","Touchez un dossier pour voir les miniatures.","Toca una carpeta para ver las miniaturas."),color=Ink.copy(alpha=.65f),fontSize=11.sp)
                    groups.forEach { group ->
                        Card(modifier=Modifier.fillMaxWidth().padding(vertical=5.dp).clickable{showFolderGroup=group.number},shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFFDCEAF2))){
                            Row(Modifier.padding(8.dp),verticalAlignment=Alignment.CenterVertically){
                                AsyncImage(model=group.representative,contentDescription=null,modifier=Modifier.size(74.dp).clickable{showFolderGroup=group.number},contentScale=androidx.compose.ui.layout.ContentScale.Crop)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)){Text("📁  ${t("Group","Gruppo","Gruppe","Groupe","Grupo")} ${group.number}",color=Ink,fontWeight=FontWeight.Bold);Text("${group.photos.size} ${t("photos","foto","Fotos","photos","fotos")}",color=Blue,fontSize=12.sp)}
                                Text("›",fontSize=28.sp,color=Blue)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(enabled=!analyzing,onClick={
                        analyzing=true;status=t("Analyzing photo quality...","Analisi della qualità delle foto...","Fotoqualität wird analysiert...","Analyse de la qualité des photos...","Analizando la calidad de las fotos...")
                        scope.launch { try { val scored=withContext(Dispatchers.IO){analyzePhotos(context,photos)};results=scored.filter{it.isGroupBest};status=t("Analysis complete. Only the best photo of each group is shown.","Analisi completata. Viene mostrata solo la migliore foto di ogni gruppo.","Analyse abgeschlossen. Nur das beste Foto jeder Gruppe wird angezeigt.","Analyse terminée. Seule la meilleure photo de chaque groupe est affichée.","Análisis completado. Solo se muestra la mejor foto de cada grupo.") } catch(_:Exception){status=t("Analysis failed. Please try again.","Analisi non riuscita. Riprova.","Analyse fehlgeschlagen. Bitte erneut versuchen.","Échec de l'analyse. Réessayez.","El análisis falló. Inténtalo de nuevo.")} finally{analyzing=false} }
                    },modifier=Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){if(analyzing)CircularProgressIndicator(modifier=Modifier.size(21.dp),color=Color.White,strokeWidth=2.dp) else Text(t("START ANALYSIS","AVVIA ANALISI","ANALYSE STARTEN","LANCER L'ANALYSE","INICIAR ANÁLISIS"),fontWeight=FontWeight.Bold)}
                }

                Text(status,color=Ink.copy(alpha=.72f),fontSize=12.sp,modifier=Modifier.padding(vertical=10.dp))

                if(results.isNotEmpty()) {
                    Text(t("BEST PHOTO OF EACH GROUP","MIGLIORE FOTO DI OGNI GRUPPO","BESTES FOTO JEDER GRUPPE","MEILLEURE PHOTO DE CHAQUE GROUPE","MEJOR FOTO DE CADA GRUPO"),color=Ink,fontWeight=FontWeight.Bold,fontSize=14.sp)
                    results.sortedBy{it.groupNumber}.forEach { best ->
                        val group = groups.firstOrNull{it.number==best.groupNumber} ?: return@forEach
                        Card(modifier=Modifier.fillMaxWidth().padding(vertical=6.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White),border=androidx.compose.foundation.BorderStroke(2.dp,Green)){
                            Column(Modifier.padding(10.dp)){
                                Row(verticalAlignment=Alignment.CenterVertically){Text("📁 ${t("Group","Gruppo","Gruppe","Groupe","Grupo")} ${group.number}",color=Ink,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("${group.photos.size} ${t("photos","foto","Fotos","photos","fotos")}",color=Blue,fontSize=11.sp)}
                                Spacer(Modifier.height(7.dp))
                                AsyncImage(model=best.uri,contentDescription=null,modifier=Modifier.fillMaxWidth().height(210.dp).clickable{openPreview(group.photos,group.photos.indexOf(best.uri).coerceAtLeast(0))},contentScale=androidx.compose.ui.layout.ContentScale.Crop)
                                Spacer(Modifier.height(7.dp))
                                Text(t("Suggested best photo","Migliore foto proposta","Vorgeschlagenes bestes Foto","Meilleure photo proposée","Mejor foto sugerida"),color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)
                                Text("${t("Score","Punteggio","Wertung","Score","Puntuación")}: ${best.score}/100",color=Ink,fontWeight=FontWeight.SemiBold,fontSize=12.sp)
                                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                    Button(onClick={requestTrash(group.photos.filter{it!=best.uri},group.number)},modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text(t("KEEP BEST & TRASH REST","MANTIENI MIGLIORE E CESTINA IL RESTO","BESTE BEHALTEN & REST IN PAPIERKORB","GARDER LA MEILLEURE ET METTRE LE RESTE À LA CORBEILLE","CONSERVAR LA MEJOR Y ENVIAR EL RESTO A LA PAPELERA"),fontSize=9.sp,fontWeight=FontWeight.Bold)}
                                    OutlinedButton(onClick={showChoiceGroup=group.number},modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp)){Text(t("CHOOSE ALTERNATIVE","SCEGLI ALTERNATIVA","ALTERNATIVE WÄHLEN","CHOISIR UNE ALTERNATIVE","ELEGIR ALTERNATIVA"),fontSize=9.sp,fontWeight=FontWeight.Bold)}
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text(t("Original photos are never deleted by this app.","Le foto originali non vengono mai eliminate dall'app.","Originalfotos werden von dieser App nie endgültig gelöscht.","Les photos originales ne sont jamais supprimées définitivement par cette application.","La aplicación nunca elimina definitivamente las fotos originales."),color=Ink.copy(alpha=.55f),fontSize=10.sp)
                Spacer(Modifier.height(20.dp))
            }
        }

        if(showStartDatePicker){val state=rememberDatePickerState(initialSelectedDateMillis=startDate?:System.currentTimeMillis());DatePickerDialog(onDismissRequest={showStartDatePicker=false},confirmButton={TextButton(onClick={startDate=startOfDay(state.selectedDateMillis);if(endDate!=null&&startDate!!>endDate!!)endDate=null;showStartDatePicker=false}){Text("OK")}},dismissButton={TextButton(onClick={showStartDatePicker=false}){Text(t("CANCEL","ANNULLA","ABBRECHEN","ANNULER","CANCELAR"))}}){DatePicker(state)}}
        if(showEndDatePicker){val state=rememberDatePickerState(initialSelectedDateMillis=endDate?:System.currentTimeMillis());DatePickerDialog(onDismissRequest={showEndDatePicker=false},confirmButton={TextButton(onClick={endDate=endOfDay(state.selectedDateMillis);if(startDate!=null&&endDate!!<startDate!!)startDate=null;showEndDatePicker=false}){Text("OK")}},dismissButton={TextButton(onClick={showEndDatePicker=false}){Text(t("CANCEL","ANNULLA","ABBRECHEN","ANNULER","CANCELAR"))}}){DatePicker(state)}}

        if(previewGroup.isNotEmpty()){
            PhotoViewerDialog(list=previewGroup,index=previewIndex,onIndexChange={previewIndex=it},onClose={previewGroup=emptyList()})
        }
        showFolderGroup?.let { number ->
            val group = groups.firstOrNull { it.number == number }
            if (group != null) {
                AlertDialog(
                    onDismissRequest = { showFolderGroup = null },
                    title = { Text("📁 ${t("Group","Gruppo","Gruppe","Groupe","Grupo")} ${group.number}") },
                    text = {
                        Column {
                            Text(t("Tap a thumbnail to enlarge. X removes it from this analysis.", "Tocca una miniatura per ingrandirla. X la esclude da questa analisi.", "Tippe auf ein Miniaturbild zum Vergrößern. X schließt es aus dieser Analyse aus.", "Touchez une miniature pour l'agrandir. X l'exclut de cette analyse.", "Toca una miniatura para ampliarla. X la excluye de este análisis."), fontSize = 11.sp, color = Ink.copy(alpha = .65f))
                            Spacer(Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(group.photos) { uri ->
                                    Box(Modifier.size(86.dp)) {
                                        AsyncImage(model=uri,contentDescription=null,modifier=Modifier.fillMaxSize().clickable{openPreview(group.photos,group.photos.indexOf(uri))},contentScale=androidx.compose.ui.layout.ContentScale.Crop)
                                        Box(Modifier.align(Alignment.TopEnd).size(16.dp).background(Color.Black.copy(alpha=.65f),RoundedCornerShape(50)).clickable{
                                            val remaining=group.photos.filterNot{it==uri}
                                            groups=groups.map{g->if(g.number==number)g.copy(photos=remaining,representative=remaining.firstOrNull()?:g.representative)else g}.filter{it.photos.size>=2}
                                            photos=groups.flatMap{it.photos}
                                        },contentAlignment=Alignment.Center){Text("×",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold)}
                                    }
                                }
                            }
                        }
                    },
                    confirmButton={TextButton(onClick={showFolderGroup=null}){Text(t("CLOSE","CHIUDI","SCHLIESSEN","FERMER","CERRAR"))}}
                )
            }
        }

        showChoiceGroup?.let { number ->
            val group=groups.firstOrNull{it.number==number}
            if(group!=null){
                val defaultSelected=selectedToKeep[number] ?: setOf(group.photos.firstOrNull()?.toString() ?: "")
                var localSelected by remember(number,group.photos){mutableStateOf(defaultSelected.filter{it.isNotBlank()}.toSet())}
                AlertDialog(onDismissRequest={showChoiceGroup=null},title={Text(t("Choose photos to keep","Scegli le foto da mantenere","Zu behaltende Fotos auswählen","Choisir les photos à garder","Elige las fotos que quieres conservar"))},text={Column{Text(t("You can keep more than one photo.","Puoi mantenere più di una foto.","Du kannst mehrere Fotos behalten.","Vous pouvez garder plusieurs photos.","Puedes conservar varias fotos."),fontSize=12.sp);group.photos.forEach{uri->Row(Modifier.fillMaxWidth().clickable{localSelected=if(localSelected.contains(uri.toString()))localSelected-uri.toString() else localSelected+uri.toString()}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=localSelected.contains(uri.toString()),onCheckedChange={localSelected=if(it)localSelected+uri.toString() else localSelected-uri.toString()});AsyncImage(model=uri,contentDescription=null,modifier=Modifier.size(48.dp),contentScale=androidx.compose.ui.layout.ContentScale.Crop);Spacer(Modifier.width(8.dp));Text(t("Open","Apri","Öffnen","Ouvrir","Abrir"),color=Blue,modifier=Modifier.clickable{openPreview(group.photos,group.photos.indexOf(uri))})}}}},confirmButton={TextButton(enabled=localSelected.isNotEmpty(),onClick={selectedToKeep=selectedToKeep+(number to localSelected);showChoiceGroup=null;requestTrash(group.photos.filter{!localSelected.contains(it.toString())},number)}){Text(t("KEEP SELECTED & TRASH OTHERS","MANTIENI SELEZIONATE E CESTINA LE ALTRE","AUSGEWÄHLTE BEHALTEN & REST IN PAPIERKORB","GARDER LA SÉLECTION ET METTRE LE RESTE À LA CORBEILLE","CONSERVAR SELECCIONADAS Y ENVIAR EL RESTO A LA PAPELERA"))}},dismissButton={TextButton(onClick={showChoiceGroup=null}){Text(t("CANCEL","ANNULLA","ABBRECHEN","ANNULER","CANCELAR"))}})
            }
        }

        trashRequest?.let { request ->
            LaunchedEffect(request) {
                try {
                    val pending = MediaStore.createTrashRequest(context.contentResolver, request.uris, true)
                    trashLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
                    status = t("Confirm moving the selected photos to Android Trash.", "Conferma lo spostamento delle foto selezionate nel Cestino Android.", "Bestätige das Verschieben der ausgewählten Fotos in den Android-Papierkorb.", "Confirmez le déplacement des photos sélectionnées vers la corbeille Android.", "Confirma el traslado de las fotos seleccionadas a la Papelera de Android.")
                } catch (_: Exception) {
                    status = t("Could not open Android Trash confirmation.", "Impossibile aprire la conferma del Cestino Android.", "Die Papierkorb-Bestätigung konnte nicht geöffnet werden.", "Impossible d'ouvrir la confirmation de la corbeille Android.", "No se pudo abrir la confirmación de la Papelera de Android.")
                    trashRequest = null
                }
            }
        }
    }
}

@Composable
private fun PhotoViewerDialog(list: List<Uri>, index: Int, onIndexChange: (Int) -> Unit, onClose: () -> Unit) {
    val context=LocalContext.current
    var zoom by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    Dialog(onDismissRequest=onClose){
        Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.Black)){
            Column(Modifier.fillMaxWidth().padding(6.dp),horizontalAlignment=Alignment.CenterHorizontally){
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("${index+1}/${list.size}",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(8.dp));Spacer(Modifier.weight(1f));TextButton(onClick=onClose){Text("✕",color=Color.White,fontSize=18.sp)}}
                Box(Modifier.fillMaxWidth().height(520.dp).pointerInput(index,list){detectTransformGestures{_,pan,scale,_ -> zoom=(zoom*scale).coerceIn(1f,5f);offsetX+=pan.x;offsetY+=pan.y}}.pointerInput(index,list,zoom){detectHorizontalDragGestures { _, amount ->
                        if (zoom <= 1.05f) {
                            if (amount < -70f && index < list.lastIndex) { onIndexChange(index + 1); zoom = 1f; offsetX = 0f; offsetY = 0f }
                            else if (amount > 70f && index > 0) { onIndexChange(index - 1); zoom = 1f; offsetX = 0f; offsetY = 0f }
                        }
                    }}.pointerInput(index,list){detectTapGestures(onDoubleTap={zoom=if(zoom>1f)1f else 2.5f})},contentAlignment=Alignment.Center){
                    AsyncImage(model=list[index],contentDescription=null,modifier=Modifier.fillMaxSize().graphicsLayer{scaleX=zoom;scaleY=zoom;translationX=offsetX;translationY=offsetY},contentScale=androidx.compose.ui.layout.ContentScale.Fit)
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){TextButton(enabled=index>0,onClick={onIndexChange(index-1);zoom=1f;offsetX=0f;offsetY=0f}){Text("‹",color=Color.White,fontSize=32.sp)};Spacer(Modifier.width(1.dp));TextButton(enabled=index<list.lastIndex,onClick={onIndexChange(index+1);zoom=1f;offsetX=0f;offsetY=0f}){Text("›",color=Color.White,fontSize=32.sp)}}
            }
        }
    }
}

private fun startOfDay(millis: Long?): Long? = millis?.let { Calendar.getInstance().apply { timeInMillis = it; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis }

private fun endOfDay(millis: Long?): Long? = millis?.let { Calendar.getInstance().apply { timeInMillis = it; set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }.timeInMillis }

private fun formatDate(millis: Long): String = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(java.util.Date(millis))

private fun loadCandidatePhotos(context: android.content.Context, startDate: Long?, endDate: Long?): List<Uri> {
    val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN, MediaStore.Images.Media.DATE_ADDED)
    val output = mutableListOf<Pair<Long, Uri>>()
    context.contentResolver.query(collection, projection, null, null, MediaStore.Images.Media.DATE_TAKEN + " ASC")?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val takenCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
        val addedCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_ADDED)
        while(cursor.moveToNext()){
            val id=cursor.getLong(idCol)
            val taken=if(takenCol>=0&&!cursor.isNull(takenCol))cursor.getLong(takenCol) else 0L
            val added=if(addedCol>=0&&!cursor.isNull(addedCol))cursor.getLong(addedCol)*1000L else 0L
            val ts=if(taken>0)taken else added
            if((startDate==null||ts>=startDate)&&(endDate==null||ts<=endDate))output.add(ts to Uri.withAppendedPath(collection,id.toString()))
        }
    }
    if(output.size<2)return emptyList()
    val sorted=output.sortedBy{it.first}
    val candidate=sorted.filterIndexed{index,item->
        val prev=if(index>0)item.first-sorted[index-1].first else Long.MAX_VALUE
        val next=if(index<sorted.lastIndex)sorted[index+1].first-item.first else Long.MAX_VALUE
        prev<=120_000L||next<=120_000L
    }
    return candidate.sortedByDescending{it.first}.map{it.second}
}

private data class VisualSignature(
    val uri: Uri,
    val time: Long?,
    val averageHash: Long,
    val differenceHash: Long,
    val grayGrid: FloatArray,
    val faceCenters: List<Pair<Float, Float>>
)

private fun buildVisualGroups(context: android.content.Context, uris: List<Uri>): List<PhotoGroup> {
    if (uris.size < 2) return emptyList()

    val options = FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
        .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
        .build()
    val detector = FaceDetection.getClient(options)

    try {
        val signatures = uris.mapNotNull { uri ->
            val bitmap = loadBitmap(context.contentResolver.openInputStream(uri)) ?: return@mapNotNull null
            try {
                val image = InputImage.fromBitmap(bitmap, 0)
                val faces = try { Tasks.await(detector.process(image)) } catch (_: Exception) { emptyList() }
                val centers = faces.map {
                    Pair(
                        it.boundingBox.centerX().toFloat() / bitmap.width.coerceAtLeast(1),
                        it.boundingBox.centerY().toFloat() / bitmap.height.coerceAtLeast(1)
                    )
                }.sortedBy { it.first }
                VisualSignature(
                    uri = uri,
                    time = readCaptureTime(context, uri),
                    averageHash = calculateAverageHash(bitmap),
                    differenceHash = calculateDifferenceHash(bitmap),
                    grayGrid = calculateGrayGrid(bitmap),
                    faceCenters = centers
                )
            } finally {
                bitmap.recycle()
            }
        }.sortedBy { it.time ?: Long.MAX_VALUE }

        if (signatures.size < 2) return emptyList()

        // Build a graph instead of comparing only with the immediately previous photo.
        // This lets a slightly different middle frame stay in the same burst and also
        // merges two pieces of the same sequence when both contain visually similar frames.
        val parent = IntArray(signatures.size) { it }

        fun find(x0: Int): Int {
            var x = x0
            while (parent[x] != x) {
                parent[x] = parent[parent[x]]
                x = parent[x]
            }
            return x
        }
        fun union(a: Int, b: Int) {
            val ra = find(a)
            val rb = find(b)
            if (ra != rb) parent[rb] = ra
        }

        for (i in signatures.indices) {
            val ti = signatures[i].time ?: continue
            for (j in i - 1 downTo 0) {
                val tj = signatures[j].time ?: continue
                val delta = ti - tj
                if (delta > 120_000L) break
                if (areVisuallySimilar(signatures[i], signatures[j])) union(i, j)
            }
        }

        val grouped = linkedMapOf<Int, MutableList<VisualSignature>>()
        signatures.indices.forEach { index ->
            grouped.getOrPut(find(index)) { mutableListOf() }.add(signatures[index])
        }

        return grouped.values
            .filter { it.size >= 2 }
            .sortedBy { it.minOfOrNull { photo -> photo.time ?: Long.MAX_VALUE } ?: Long.MAX_VALUE }
            .mapIndexed { index, group ->
                val ordered = group.sortedBy { it.time ?: Long.MAX_VALUE }
                PhotoGroup(index + 1, ordered.map { it.uri }, ordered.first().uri)
            }
    } finally {
        detector.close()
    }
}

private fun areVisuallySimilar(a: VisualSignature, b: VisualSignature): Boolean {
    val averageDistance = java.lang.Long.bitCount(a.averageHash xor b.averageHash)
    val differenceDistance = java.lang.Long.bitCount(a.differenceHash xor b.differenceHash)
    val gridDistance = grayGridDistance(a.grayGrid, b.grayGrid)
    val faceMatch = similarFaceLayoutLoose(a.faceCenters, b.faceCenters)

    // Strong structural similarity: robust to small changes in expression and pose.
    if (averageDistance <= 22 && differenceDistance <= 24) return true

    // If the same people remain in approximately the same places, allow a little more
    // image variation because this is exactly what a burst sequence is expected to contain.
    if (faceMatch && averageDistance <= 30 && differenceDistance <= 32 && gridDistance <= 0.30f) return true

    // Fallback for scenes without reliably detected faces.
    return averageDistance <= 26 && differenceDistance <= 30 && gridDistance <= 0.22f
}

private fun similarFaceLayoutLoose(a: List<Pair<Float, Float>>, b: List<Pair<Float, Float>>): Boolean {
    if (a.isEmpty() || b.isEmpty()) return false
    if (a.size != b.size) return false
    return a.zip(b).all { (left, right) ->
        val dx = left.first - right.first
        val dy = left.second - right.second
        dx * dx + dy * dy <= 0.24f * 0.24f
    }
}

private fun calculateAverageHash(bitmap: Bitmap): Long {
    val sample = Bitmap.createScaledBitmap(bitmap, 8, 8, true)
    val values = IntArray(64)
    var sum = 0L
    for (y in 0 until 8) for (x in 0 until 8) {
        val p = sample.getPixel(x, y)
        val v = (0.299 * (p shr 16 and 0xff) + 0.587 * (p shr 8 and 0xff) + 0.114 * (p and 0xff)).toInt()
        values[y * 8 + x] = v
        sum += v
    }
    sample.recycle()
    val average = sum / 64.0
    var hash = 0L
    for (i in values.indices) if (values[i] >= average) hash = hash or (1L shl i)
    return hash
}

private fun calculateDifferenceHash(bitmap: Bitmap): Long {
    val sample = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
    val gray = IntArray(72)
    for (y in 0 until 8) for (x in 0 until 9) {
        val p = sample.getPixel(x, y)
        gray[y * 9 + x] = (0.299 * (p shr 16 and 0xff) + 0.587 * (p shr 8 and 0xff) + 0.114 * (p and 0xff)).toInt()
    }
    sample.recycle()
    var hash = 0L
    var bit = 0
    for (y in 0 until 8) for (x in 0 until 8) {
        if (gray[y * 9 + x] >= gray[y * 9 + x + 1]) hash = hash or (1L shl bit)
        bit++
    }
    return hash
}

private fun calculateGrayGrid(bitmap: Bitmap): FloatArray {
    val w = 12
    val h = 12
    val sample = Bitmap.createScaledBitmap(bitmap, w, h, true)
    val values = FloatArray(w * h)
    var mean = 0f
    for (y in 0 until h) for (x in 0 until w) {
        val p = sample.getPixel(x, y)
        val v = (0.299 * (p shr 16 and 0xff) + 0.587 * (p shr 8 and 0xff) + 0.114 * (p and 0xff)).toFloat() / 255f
        values[y * w + x] = v
        mean += v
    }
    sample.recycle()
    mean /= values.size
    var variance = 0f
    values.forEach { variance += (it - mean) * (it - mean) }
    val std = kotlin.math.sqrt((variance / values.size).toDouble()).toFloat().coerceAtLeast(0.05f)
    for (i in values.indices) values[i] = ((values[i] - mean) / std).coerceIn(-3f, 3f)
    return values
}

private fun grayGridDistance(a: FloatArray, b: FloatArray): Float {
    if (a.size != b.size) return 1f
    var total = 0f
    for (i in a.indices) total += kotlin.math.abs(a[i] - b[i])
    return total / a.size / 3f
}

private fun analyzePhotos(context: android.content.Context, uris: List<Uri>): List<PhotoScore> {
    val options = FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
        .build()
    val detector = FaceDetection.getClient(options)
    try {
        val candidates = uris.mapNotNull { uri ->
            val bitmap = loadBitmap(context.contentResolver.openInputStream(uri)) ?: return@mapNotNull null
            try {
                val faces = Tasks.await(detector.process(InputImage.fromBitmap(bitmap, 0)))
                val globalSharpness = calculateSharpness(bitmap)
                val globalBrightness = calculateBrightness(bitmap)
                val faceScores = faces.map { face ->
                    val box = face.boundingBox
                    val padX = (box.width() * 0.12f).toInt()
                    val padY = (box.height() * 0.12f).toInt()
                    val left = (box.left - padX).coerceIn(0, bitmap.width - 1)
                    val top = (box.top - padY).coerceIn(0, bitmap.height - 1)
                    val right = (box.right + padX).coerceIn(left + 1, bitmap.width)
                    val bottom = (box.bottom + padY).coerceIn(top + 1, bitmap.height)
                    val crop = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
                    val faceLighting = calculateFaceLighting(crop)
                    val faceSharp = calculateSharpness(crop)
                    crop.recycle()

                    val leftEye = face.leftEyeOpenProbability
                    val rightEye = face.rightEyeOpenProbability
                    val eyeScore = when {
                        leftEye == null && rightEye == null -> 65.0
                        leftEye != null && rightEye != null -> {
                            val weakerEye = minOf(leftEye, rightEye)
                            (weakerEye * 100.0).coerceIn(0.0, 100.0)
                        }
                        else -> ((leftEye ?: rightEye ?: 0.5f) * 85.0).coerceIn(0.0, 85.0)
                    }
                    // Face illumination is measured inside the face crop, not from the whole photo.
                    // The lower quartile and dark-pixel ratio help detect a face partly lost in shadow.
                    val meanLightScore = ((faceLighting.mean - 0.16) / 0.34 * 100.0).coerceIn(0.0, 100.0)
                    val lowerLightScore = ((faceLighting.lowerQuartile - 0.10) / 0.30 * 100.0).coerceIn(0.0, 100.0)
                    val shadowScore = (100.0 - faceLighting.shadowFraction * 190.0).coerceIn(0.0, 100.0)
                    val lightScore = (meanLightScore * 0.45 + lowerLightScore * 0.30 + shadowScore * 0.25).coerceIn(0.0, 100.0)
                    val sharpFaceScore = (sqrt(faceSharp.coerceAtLeast(0.0)) / 12.0 * 100.0).coerceIn(0.0, 100.0)
                    val smile = face.smilingProbability
                    // A natural/neutral expression remains valid; a detected smile is a small bonus only.
                    val expressionScore = if (smile == null) 75.0 else (75.0 + smile * 25.0).coerceIn(75.0, 100.0)
                    eyeScore * 0.35 + lightScore * 0.35 + sharpFaceScore * 0.20 + expressionScore * 0.10
                }
                val openEyes = faces.count { face ->
                    val l = face.leftEyeOpenProbability
                    val r = face.rightEyeOpenProbability
                    (l == null && r == null) || ((l ?: 0f) >= 0.45f && (r ?: 0f) >= 0.45f)
                }
                val globalSharpScore = (sqrt(globalSharpness.coerceAtLeast(0.0)) / 18.0 * 100.0).coerceIn(0.0, 100.0)
                val globalLightScore = (100.0 - abs(globalBrightness - 0.52) * 150.0).coerceIn(0.0, 100.0)
                val clippedFraction = calculateClippedFraction(bitmap)
                val exposurePenalty = when {
                    globalBrightness < 0.075 || globalBrightness > 0.94 -> 28.0
                    globalBrightness < 0.12 || globalBrightness > 0.88 -> 16.0
                    else -> 0.0
                } + (clippedFraction * 55.0).coerceAtMost(22.0)
                val blurPenalty = if (globalSharpScore < 18.0) 24.0 else if (globalSharpScore < 30.0) 12.0 else 0.0
                val closedEyeFaces = faces.count { face ->
                    val l = face.leftEyeOpenProbability
                    val r = face.rightEyeOpenProbability
                    l != null && r != null && l < 0.22f && r < 0.22f
                }
                val technicalRejected = globalSharpScore < 12.0 ||
                    globalBrightness < 0.045 || globalBrightness > 0.97 ||
                    (clippedFraction > 0.48 && (globalBrightness < 0.12 || globalBrightness > 0.88)) ||
                    (faces.isNotEmpty() && closedEyeFaces == faces.size)
                val overall = if (faceScores.isEmpty()) {
                    (globalSharpScore * 0.55 + globalLightScore * 0.45 - exposurePenalty - blurPenalty - if (technicalRejected) 35.0 else 0.0).coerceIn(0.0, 100.0)
                } else {
                    val averageFaces = faceScores.average()
                    val weakestFace = faceScores.minOrNull() ?: averageFaces
                    // Group photos are judged by everyone, not just the average: the weakest face
                    // receives half of the face-quality weight and very poor faces are penalized.
                    val groupFaces = averageFaces * 0.50 + weakestFace * 0.50
                    val severeSingleFacePenalty = when {
                        weakestFace < 30.0 -> (30.0 - weakestFace) * 0.90
                        weakestFace < 50.0 -> (50.0 - weakestFace) * 0.45
                        else -> 0.0
                    }
                    (globalSharpScore * 0.10 + globalLightScore * 0.05 + groupFaces * 0.85 - severeSingleFacePenalty - exposurePenalty - blurPenalty - if (technicalRejected) 35.0 else 0.0).coerceIn(0.0, 100.0)
                }
                val details = buildList {
                    add("${faces.size} faces detected")
                    if (faces.isNotEmpty()) add("$openEyes/${faces.size} faces with open/uncertain eyes")
                    add(if (globalSharpScore >= 60) "good overall sharpness" else "limited overall sharpness")
                    if (faceScores.isNotEmpty() && (faceScores.minOrNull() ?: 100.0) < 55.0) add("one face has weak lighting, focus or eyes")
                    add(if (globalLightScore >= 60) "balanced overall light" else "challenging overall light")
                    if (exposurePenalty > 12.0) add("technical warning: exposure/clipped highlights")
                    if (blurPenalty > 0.0) add("technical warning: possible blur")
                    if (technicalRejected) add("strong technical rejection flag")
                    if (faceScores.isNotEmpty() && (faceScores.minOrNull() ?: 100.0) < 45.0) add("reject from top shortlist: one face needs attention")
                }.joinToString(" • ")
                PhotoCandidate(
                    uri = uri,
                    score = overall.toInt().coerceIn(0, 100),
                    sharpness = globalSharpness,
                    brightness = globalBrightness,
                    faceCount = faces.size,
                    openEyes = openEyes,
                    timestampMs = readCaptureTime(context, uri),
                    sceneHash = calculateSceneHash(bitmap),
                    faceCenters = faces.map { face ->
                        Pair(face.boundingBox.centerX().toFloat() / bitmap.width, face.boundingBox.centerY().toFloat() / bitmap.height)
                    }.sortedBy { it.first },
                    technicalRejected = technicalRejected,
                    explanation = details
                )
            } finally {
                bitmap.recycle()
            }
        }

        // Use the exact same visual grouping engine as the folder screen so that
        // analysis never splits a burst into different groups again.
        val visualGroups = buildVisualGroups(context, candidates.map { it.uri })
        return visualGroups.flatMap { group ->
            val ranked = group.photos.mapNotNull { uri -> candidates.firstOrNull { it.uri == uri } }
                .sortedWith(compareBy<PhotoCandidate> { it.technicalRejected }.thenByDescending { it.score })
            val winner = ranked.firstOrNull { !it.technicalRejected } ?: ranked.firstOrNull()
            val groupNumber = group.number
            ranked.mapIndexed { rankIndex, item ->
                PhotoScore(item.uri, item.score, item.sharpness, item.brightness, item.faceCount,
                    item.openEyes, groupNumber, item.uri == winner?.uri,
                    rankIndex < 3 && !item.technicalRejected,
                    rankIndex + 1, item.technicalRejected, item.explanation)
            }
        }
    } finally {
        detector.close()
    }
}

private fun readCaptureTime(context: android.content.Context, uri: Uri): Long? {
    val mediaStoreTime = try {
        context.contentResolver.query(uri, arrayOf(MediaStore.Images.Media.DATE_TAKEN), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
                if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index).takeIf { it > 0L } else null
            } else null
        }
    } catch (_: Exception) { null }
    if (mediaStoreTime != null) return mediaStoreTime
    return try {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val exif = ExifInterface(stream)
            val date = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) ?: return@use null
            val offset = exif.getAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL)
            val parser = if (!offset.isNullOrBlank()) SimpleDateFormat("yyyy:MM:dd HH:mm:ssXXX", Locale.US)
                else SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
            parser.parse(if (!offset.isNullOrBlank()) date + offset else date)?.time
        }
    } catch (_: Exception) { null }
}

private fun similarFaceLayout(a: List<Pair<Float, Float>>, b: List<Pair<Float, Float>>): Boolean {
    if (a.size != b.size) return false
    if (a.isEmpty()) return true
    return a.zip(b).all { (left, right) ->
        val dx = left.first - right.first
        val dy = left.second - right.second
        dx * dx + dy * dy <= 0.18f * 0.18f
    }
}

private fun calculateSceneHash(bitmap: Bitmap): Long {
    val sample = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
    val gray = IntArray(9 * 8)
    for (y in 0 until 8) for (x in 0 until 9) {
        val p = sample.getPixel(x, y)
        val r = (p shr 16 and 0xff)
        val g = (p shr 8 and 0xff)
        val b = (p and 0xff)
        gray[y * 9 + x] = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
    }
    sample.recycle()
    var hash = 0L
    var bit = 0
    for (y in 0 until 8) for (x in 0 until 8) {
        if (gray[y * 9 + x] > gray[y * 9 + x + 1]) hash = hash or (1L shl bit)
        bit++
    }
    return hash
}

private fun loadBitmap(stream: InputStream?): Bitmap? {
    if (stream == null) return null
    return stream.use { input ->
        val bytes = input.readBytes()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }
}


private fun calculateFaceLighting(bitmap: Bitmap): FaceLightingStats {
    // Ignore a narrow border around the detector box, where hair and background can distort
    // the measurement. Sample the central face area and inspect its darker quarter as well.
    val left = (bitmap.width * 0.12f).toInt().coerceIn(0, bitmap.width - 1)
    val top = (bitmap.height * 0.12f).toInt().coerceIn(0, bitmap.height - 1)
    val right = (bitmap.width * 0.88f).toInt().coerceIn(left + 1, bitmap.width)
    val bottom = (bitmap.height * 0.88f).toInt().coerceIn(top + 1, bitmap.height)
    val stepX = ((right - left) / 48).coerceAtLeast(1)
    val stepY = ((bottom - top) / 48).coerceAtLeast(1)
    val samples = ArrayList<Double>()
    for (y in top until bottom step stepY) {
        for (x in left until right step stepX) {
            val p = bitmap.getPixel(x, y)
            val r = (p shr 16 and 0xff) / 255.0
            val g = (p shr 8 and 0xff) / 255.0
            val b = (p and 0xff) / 255.0
            samples.add(0.2126 * r + 0.7152 * g + 0.0722 * b)
        }
    }
    if (samples.isEmpty()) return FaceLightingStats(0.5, 0.35, 0.0)
    samples.sort()
    val mean = samples.average()
    val lowerQuartile = samples[(samples.size * 0.25).toInt().coerceIn(0, samples.lastIndex)]
    val shadowFraction = samples.count { it < 0.18 }.toDouble() / samples.size
    return FaceLightingStats(mean, lowerQuartile, shadowFraction)
}

private fun calculateClippedFraction(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 100).coerceAtLeast(1)
    val stepY = (bitmap.height / 100).coerceAtLeast(1)
    var clipped = 0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16) and 0xff
            val g = (pixel shr 8) and 0xff
            val b = pixel and 0xff
            val luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
            if (luminance < 12.0 || luminance > 248.0) clipped++
            count++
        }
    }
    return if (count == 0) 0.0 else clipped.toDouble() / count
}

private fun calculateBrightness(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 80).coerceAtLeast(1)
    val stepY = (bitmap.height / 80).coerceAtLeast(1)
    var sum = 0.0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16 and 0xff) / 255.0
            val g = (pixel shr 8 and 0xff) / 255.0
            val b = (pixel and 0xff) / 255.0
            sum += 0.2126 * r + 0.7152 * g + 0.0722 * b
            count++
        }
    }
    return if (count == 0) 0.5 else sum / count
}

private fun calculateSharpness(bitmap: Bitmap): Double {
    val scale = minOf(1.0, 240.0 / maxOf(bitmap.width, bitmap.height))
    val w = (bitmap.width * scale).toInt().coerceAtLeast(3)
    val h = (bitmap.height * scale).toInt().coerceAtLeast(3)
    val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
    val values = DoubleArray(w * h)
    for (y in 0 until h) for (x in 0 until w) {
        val p = small.getPixel(x, y)
        val r = (p shr 16 and 0xff).toDouble()
        val g = (p shr 8 and 0xff).toDouble()
        val b = (p and 0xff).toDouble()
        values[y * w + x] = 0.299 * r + 0.587 * g + 0.114 * b
    }
    var sum = 0.0
    var sumSq = 0.0
    var count = 0
    for (y in 1 until h - 1) for (x in 1 until w - 1) {
        val i = y * w + x
        val lap = values[i - w] + values[i - 1] - 4 * values[i] + values[i + 1] + values[i + w]
        sum += lap
        sumSq += lap * lap
        count++
    }
    small.recycle()
    if (count == 0) return 0.0
    val mean = sum / count
    return (sumSq / count - mean * mean).coerceAtLeast(0.0)
}

@Composable
private fun ChoiceCard(
    title: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    selected: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) Blue else Color(0xFFDCEAF2)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFEAF6FC), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Ink.copy(alpha = .62f), fontSize = 11.sp)
            }
            RadioButton(selected = selected, onClick = onClick)
        }
    }
}
