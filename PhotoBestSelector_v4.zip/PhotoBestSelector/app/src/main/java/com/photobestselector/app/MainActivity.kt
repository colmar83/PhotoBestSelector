package com.photobestselector.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.text.SimpleDateFormat
import java.util.Locale
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import java.util.Calendar
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import kotlin.math.abs
import kotlin.math.sqrt

private val Ink = Color(0xFF18324A)
private val Blue = Color(0xFF2686C9)
private val Green = Color(0xFF19A66A)
private val Pale = Color(0xFFF3FAFE)

private data class FaceLightingStats(
    val mean: Double,
    val lowerQuartile: Double,
    val shadowFraction: Double
)

private data class PhotoScore(
    val uri: Uri,
    val score: Int,
    val sharpness: Double,
    val brightness: Double,
    val faceCount: Int,
    val openEyes: Int,
    val groupNumber: Int,
    val isGroupBest: Boolean,
    val isFinalist: Boolean,
    val finalistRank: Int,
    val technicalRejected: Boolean,
    val explanation: String
)

private data class PhotoCandidate(
    val uri: Uri,
    val score: Int,
    val sharpness: Double,
    val brightness: Double,
    val faceCount: Int,
    val openEyes: Int,
    val timestampMs: Long?,
    val sceneHash: Long,
    val faceCenters: List<Pair<Float, Float>>,
    val technicalRejected: Boolean,
    val explanation: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoBestSelectorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoBestSelectorApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var status by remember { mutableStateOf("Choose photos from your gallery to compare them.") }
    var analyzing by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<PhotoScore>>(emptyList()) }
    var preview by remember { mutableStateOf<Uri?>(null) }
    var previewScale by remember { mutableFloatStateOf(1f) }
    val previewTransform = rememberTransformableState { zoomChange, _, _ -> previewScale = (previewScale * zoomChange).coerceIn(1f, 5f) }
    var language by remember { mutableStateOf("en") }
    var languageMenu by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var startDate by remember { mutableStateOf<Long?>(null) }
    var endDate by remember { mutableStateOf<Long?>(null) }
    var showStartDatePicker by remember { mutableStateOf(false) }
    var showEndDatePicker by remember { mutableStateOf(false) }
    var pendingAllPhotos by remember { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("photo_best_selector", android.content.Context.MODE_PRIVATE) }

    val readImagesPermission = if (android.os.Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && pendingAllPhotos) {
            pendingAllPhotos = false
            scope.launch {
                analyzing = true
                status = t("Searching and analyzing the selected dates...", "Ricerca e analisi delle date selezionate...", "Suche und Analyse der ausgewählten Daten...", "Recherche et analyse des dates sélectionnées...", "Buscando y analizando las fechas seleccionadas...")
                try {
                    val loaded = withContext(Dispatchers.IO) { loadAllPhotos(context, startDate, endDate) }
                    val scored = withContext(Dispatchers.IO) { analyzePhotos(context, loaded) }
                    results = scored.sortedWith(compareBy<PhotoScore> { it.technicalRejected }.thenByDescending { it.score })
                    photos = results.map { it.uri }.distinct()
                    status = if (results.isNotEmpty()) t("Valid photo sequences found. Single photos are excluded.", "Sequenze valide trovate. Le foto singole sono escluse.", "Gültige Fotoserien gefunden. Einzelbilder werden ausgeschlossen.", "Séquences valides trouvées. Les photos isolées sont exclues.", "Secuencias válidas encontradas. Las fotos individuales se excluyen.") else t("No valid photo sequences found in this date range. Single photos are excluded.", "Nessuna sequenza valida trovata in questo intervallo. Le foto singole sono escluse.", "Keine gültigen Fotoserien in diesem Zeitraum gefunden. Einzelbilder werden ausgeschlossen.", "Aucune séquence valide trouvée dans cette période. Les photos isolées sont exclues.", "No se encontraron secuencias válidas en este periodo. Las fotos individuales se excluyen.")
                } catch (_: Exception) {
                    status = t("Search or analysis failed. Please try again.", "Ricerca o analisi non riuscita. Riprova.", "Suche oder Analyse fehlgeschlagen. Bitte erneut versuchen.", "Échec de la recherche ou de l'analyse. Réessayez.", "Falló la búsqueda o el análisis. Inténtalo de nuevo.")
                } finally { analyzing = false }
            }
        }
    }
    LaunchedEffect(Unit) {
        language = prefs.getString("language", "en") ?: "en"
        favorites = prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
    }
    fun t(en: String, it: String, de: String, fr: String, es: String): String = when (language) {
        "it" -> it; "de" -> de; "fr" -> fr; "es" -> es; else -> en
    }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(200)
    ) { uris ->
        photos = uris
        results = emptyList()
        status = if (uris.isNotEmpty()) "${uris.size} photos selected. Ready to analyze." else t("No photos selected.", "Nessuna foto selezionata.", "Keine Fotos ausgewählt.", "Aucune photo sélectionnée.", "No se seleccionaron fotos.")
    }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, secondary = Green, background = Pale, surface = Color.White, onSurface = Ink)
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PhotoBestSelector", fontWeight = FontWeight.Bold, color = Ink)
                            Text("Find Your Perfect Shot.", fontSize = 12.sp, color = Blue)
                        }
                    },
                    actions = {
                        Box {
                            TextButton(onClick = { languageMenu = true }) { Text(language.uppercase(), color = Ink, fontWeight = FontWeight.Bold) }
                            DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                                listOf("en" to "English", "it" to "Italiano", "de" to "Deutsch", "fr" to "Français", "es" to "Español").forEach { (code, label) ->
                                    DropdownMenuItem(text = { Text(label) }, onClick = {
                                        language = code; prefs.edit().putString("language", code).apply(); languageMenu = false
                                    })
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE1F2FB)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📸", fontSize = 40.sp)
                        Text(t("Many photos. One winner.", "Tante foto. Uno scatto vincente.", "Viele Fotos. Ein Gewinner.", "Plusieurs photos. Une gagnante.", "Muchas fotos. Una ganadora."), color = Ink, fontWeight = FontWeight.Bold)
                        Text(t("All photos stay together on one screen.", "Tutte le foto restano in un'unica schermata.", "Alle Fotos bleiben auf einem Bildschirm.", "Toutes les photos restent sur un seul écran.", "Todas las fotos aparecen en una sola pantalla."), color = Ink.copy(alpha = .7f), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) { Text(t("CHOOSE PHOTOS", "SCEGLI FOTO", "FOTOS AUSWÄHLEN", "CHOISIR DES PHOTOS", "ELEGIR FOTOS"), fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        pendingAllPhotos = true
                        if (ContextCompat.checkSelfPermission(context, readImagesPermission) == PackageManager.PERMISSION_GRANTED) {
                            pendingAllPhotos = false
                            scope.launch {
                                val loaded = withContext(Dispatchers.IO) { loadAllPhotos(context, startDate, endDate) }
                                photos = loaded; results = emptyList()
                                status = if (loaded.isNotEmpty()) "${loaded.size} photos loaded. Ready to analyze." else t("No photos found for this date range.", "Nessuna foto trovata per questo intervallo.", "Keine Fotos für diesen Zeitraum gefunden.", "Aucune photo trouvée pour cette période.", "No se encontraron fotos en este periodo.")
                            }
                        } else permissionLauncher.launch(readImagesPermission)
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)
                ) { Text(t("SELECT ALL PHOTOS", "SELEZIONA TUTTE LE FOTO", "ALLE FOTOS AUSWÄHLEN", "SÉLECTIONNER TOUTES LES PHOTOS", "SELECCIONAR TODAS LAS FOTOS"), fontWeight = FontWeight.Bold) }

                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { showStartDatePicker = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text(startDate?.let { formatDate(it) } ?: t("FROM DATE", "DATA INIZIO", "STARTDATUM", "DATE DE DÉBUT", "FECHA INICIO"), fontSize = 11.sp)
                    }
                    OutlinedButton(onClick = { showEndDatePicker = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text(endDate?.let { formatDate(it) } ?: t("TO DATE", "DATA FINE", "ENDDATUM", "DATE DE FIN", "FECHA FIN"), fontSize = 11.sp)
                    }
                }
                if (startDate != null || endDate != null) {
                    TextButton(onClick = { startDate = null; endDate = null }) {
                        Text(t("CLEAR DATE FILTER", "CANCELLA FILTRO DATA", "DATUMSFILTER LÖSCHEN", "EFFACER LE FILTRE DE DATE", "BORRAR FILTRO DE FECHA"), color = Blue, fontSize = 11.sp)
                    }
                }
                Button(
                    onClick = {
                        if (startDate != null && endDate != null && startDate!! > endDate!!) {
                            status = t("Start date must be before end date.", "La data iniziale deve precedere quella finale.", "Das Startdatum muss vor dem Enddatum liegen.", "La date de début doit précéder la date de fin.", "La fecha inicial debe ser anterior a la fecha final.")
                        } else {
                            pendingAllPhotos = true
                            if (ContextCompat.checkSelfPermission(context, readImagesPermission) == PackageManager.PERMISSION_GRANTED) {
                                pendingAllPhotos = false
                                scope.launch {
                                    analyzing = true
                                    status = t("Searching and analyzing the selected dates...", "Ricerca e analisi delle date selezionate...", "Suche und Analyse der ausgewählten Daten...", "Recherche et analyse des dates sélectionnées...", "Buscando y analizando las fechas seleccionadas...")
                                    try {
                                        val loaded = withContext(Dispatchers.IO) { loadAllPhotos(context, startDate, endDate) }
                                        val scored = withContext(Dispatchers.IO) { analyzePhotos(context, loaded) }
                                        results = scored.sortedWith(compareBy<PhotoScore> { it.technicalRejected }.thenByDescending { it.score })
                                        photos = results.map { it.uri }.distinct()
                                        status = if (results.isNotEmpty()) t("Valid photo sequences found. Single photos are excluded.", "Sequenze valide trovate. Le foto singole sono escluse.", "Gültige Fotoserien gefunden. Einzelbilder werden ausgeschlossen.", "Séquences valides trouvées. Les photos isolées sont exclues.", "Secuencias válidas encontradas. Las fotos individuales se excluyen.") else t("No valid photo sequences found in this date range. Single photos are excluded.", "Nessuna sequenza valida trovata in questo intervallo. Le foto singole sono escluse.", "Keine gültigen Fotoserien in diesem Zeitraum gefunden. Einzelbilder werden ausgeschlossen.", "Aucune séquence valide trouvée dans cette période. Les photos isolées sont exclues.", "No se encontraron secuencias válidas en este periodo. Las fotos individuales se excluyen.")
                                    } catch (_: Exception) {
                                        status = t("Search or analysis failed. Please try again.", "Ricerca o analisi non riuscita. Riprova.", "Suche oder Analyse fehlgeschlagen. Bitte erneut versuchen.", "Échec de la recherche ou de l'analyse. Réessayez.", "Falló la búsqueda o el análisis. Inténtalo de nuevo.")
                                    } finally { analyzing = false }
                                }
                            } else permissionLauncher.launch(readImagesPermission)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) { Text(t("CONFIRM DATES & SEARCH", "CONFERMA DATE E CERCA", "DATEN BESTÄTIGEN & SUCHEN", "CONFIRMER LES DATES ET RECHERCHER", "CONFIRMAR FECHAS Y BUSCAR"), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                if (photos.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("${photos.size} ${t("photos selected", "foto selezionate", "Fotos ausgewählt", "photos sélectionnées", "fotos seleccionadas")}", color = Green, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(photos) { uri ->
                            AsyncImage(model = uri, contentDescription = "Selected photo", modifier = Modifier.size(66.dp).clickable { previewScale = 1f; preview = uri }, contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        enabled = !analyzing,
                        onClick = {
                            analyzing = true; results = emptyList()
                            status = t("Analyzing photos on this device...", "Analisi delle foto sul dispositivo...", "Fotos werden auf diesem Gerät analysiert...", "Analyse des photos sur cet appareil...", "Analizando fotos en este dispositivo...")
                            scope.launch {
                                try {
                                    val scored = withContext(Dispatchers.IO) { analyzePhotos(context, photos) }
                                    results = scored.sortedWith(compareBy<PhotoScore> { it.technicalRejected }.thenByDescending { it.score })
                                    photos = results.map { it.uri }.distinct()
                                    status = if (scored.isEmpty()) t("No valid photo sequences found. Single photos are excluded.", "Nessuna sequenza valida trovata. Le foto singole sono escluse.", "Keine gültigen Fotoserien gefunden. Einzelbilder werden ausgeschlossen.", "Aucune séquence valide trouvée. Les photos isolées sont exclues.", "No se encontraron secuencias válidas. Las fotos individuales se excluyen.") else t("Analysis complete.", "Analisi completata.", "Analyse abgeschlossen.", "Analyse terminée.", "Análisis completado.")
                                } catch (_: Exception) {
                                    status = t("Analysis failed. Please try again.", "Analisi non riuscita. Riprova.", "Analyse fehlgeschlagen. Bitte erneut versuchen.", "Échec de l'analyse. Réessayez.", "El análisis falló. Inténtalo de nuevo.")
                                } finally { analyzing = false }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Green)
                    ) {
                        if (analyzing) CircularProgressIndicator(modifier = Modifier.size(21.dp), color = Color.White, strokeWidth = 2.dp)
                        else Text(t("START ANALYSIS", "AVVIA ANALISI", "ANALYSE STARTEN", "LANCER L'ANALYSE", "INICIAR ANÁLISIS"), fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(status, color = Ink.copy(alpha = .72f), fontSize = 12.sp)
                if (results.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    val finalists = results.filter { it.isFinalist && !it.technicalRejected }
                    Text(t("TOP SHOTS — TAP TO ENLARGE", "MIGLIORI SCATTI — TOCCA PER INGRANDIRE", "BESTE FOTOS — ZUM VERGRÖSSERN TIPPEN", "MEILLEURES PHOTOS — TOUCHER POUR AGRANDIR", "MEJORES FOTOS — TOCA PARA AMPLIAR"), color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(finalists) { item ->
                            Card(shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(2.dp, if (item.isGroupBest) Green else Blue)) {
                                Column(Modifier.width(132.dp).clickable { previewScale = 1f; preview = item.uri }.padding(6.dp)) {
                                    AsyncImage(model = item.uri, contentDescription = "Best candidate", modifier = Modifier.fillMaxWidth().height(116.dp), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                    Text("${item.score}/100", color = Ink, fontWeight = FontWeight.Bold)
                                    Text(if (item.isGroupBest) t("Sequence winner", "Migliore sequenza", "Sequenzsieger", "Meilleure séquence", "Mejor de secuencia") else t("Alternative", "Alternativa", "Alternative", "Alternative", "Alternativa"), color = Blue, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(t("ALL PHOTOS", "TUTTE LE FOTO", "ALLE FOTOS", "TOUTES LES PHOTOS", "TODAS LAS FOTOS"), color = Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    results.forEach { item ->
                        val key = item.uri.toString()
                        val isFav = favorites.contains(key)
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(model = item.uri, contentDescription = "Photo", modifier = Modifier.size(88.dp).clickable { previewScale = 1f; preview = item.uri }, contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(when { item.technicalRejected -> t("TECHNICAL WARNING", "PROBLEMA TECNICO", "TECHNISCHER HINWEIS", "ALERTE TECHNIQUE", "AVISO TÉCNICO"); item.isGroupBest -> t("BEST IN SEQUENCE", "MIGLIORE DELLA SEQUENZA", "BESTE DER SERIE", "MEILLEURE DE LA SÉRIE", "MEJOR DE LA SECUENCIA"); item.isFinalist -> t("TOP 3 CANDIDATE", "CANDIDATA TOP 3", "TOP-3-KANDIDAT", "CANDIDATE TOP 3", "CANDIDATA TOP 3"); else -> t("OTHER PHOTO", "ALTRA FOTO", "ANDERES FOTO", "AUTRE PHOTO", "OTRA FOTO") }, color = if (item.technicalRejected) Color(0xFFB45A35) else if (item.isGroupBest) Green else Blue, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    Text("${t("Score", "Punteggio", "Wertung", "Score", "Puntuación")}: ${item.score}/100", color = Ink, fontWeight = FontWeight.SemiBold)
                                    Text("${item.faceCount} ${t("faces", "volti", "Gesichter", "visages", "rostros")} • ${item.openEyes} ${t("open/uncertain eyes", "occhi aperti/incerti", "offene/unklare Augen", "yeux ouverts/incertains", "ojos abiertos/dudosos")}", color = Ink.copy(alpha = .68f), fontSize = 10.sp)
                                }
                                IconButton(onClick = {
                                    favorites = if (isFav) favorites - key else favorites + key
                                    prefs.edit().putStringSet("favorites", favorites).apply()
                                }) { Icon(if (isFav) Icons.Default.Star else Icons.Default.StarBorder, contentDescription = "Favorite", tint = if (isFav) Color(0xFFE0A000) else Ink) }
                            }
                        }
                    }
                    Text(t("The app checks technical quality and each detected face separately. Composition, posture and emotional impact still need your visual final check. Originals are never deleted.", "L'app valuta qualità tecnica e ogni volto separatamente. Composizione, postura ed emozione richiedono ancora il tuo controllo visivo. Gli originali non vengono mai eliminati.", "Die App prüft technische Qualität und jedes Gesicht einzeln. Bildaufbau, Haltung und Ausdruck brauchen weiterhin deine Sichtprüfung. Originale werden nie gelöscht.", "L'application évalue la qualité technique et chaque visage séparément. La composition, la posture et l'émotion nécessitent encore votre vérification. Les originaux ne sont jamais supprimés.", "La app evalúa la calidad técnica y cada rostro por separado. La composición, postura y emoción aún requieren tu revisión visual. Los originales nunca se eliminan."), color = Ink.copy(alpha = .6f), fontSize = 11.sp, lineHeight = 15.sp)
                }
                Spacer(Modifier.height(16.dp))
                Text("Private by design • Original photos stay untouched", color = Ink.copy(alpha = .55f), fontSize = 10.sp)
                Spacer(Modifier.height(16.dp))
            }
        }
        if (showStartDatePicker) {
            val state = rememberDatePickerState(initialSelectedDateMillis = startDate ?: System.currentTimeMillis())
            DatePickerDialog(onDismissRequest = { showStartDatePicker = false }, confirmButton = {
                TextButton(onClick = { startDate = startOfDay(state.selectedDateMillis); if (endDate != null && startDate!! > endDate!!) endDate = null; showStartDatePicker = false }) { Text(t("OK", "OK", "OK", "OK", "OK")) }
            }, dismissButton = { TextButton(onClick = { showStartDatePicker = false }) { Text(t("CANCEL", "ANNULLA", "ABBRECHEN", "ANNULER", "CANCELAR")) } }) { DatePicker(state) }
        }
        if (showEndDatePicker) {
            val state = rememberDatePickerState(initialSelectedDateMillis = endDate ?: System.currentTimeMillis())
            DatePickerDialog(onDismissRequest = { showEndDatePicker = false }, confirmButton = {
                TextButton(onClick = { endDate = endOfDay(state.selectedDateMillis); if (startDate != null && endDate!! < startDate!!) startDate = null; showEndDatePicker = false }) { Text(t("OK", "OK", "OK", "OK", "OK")) }
            }, dismissButton = { TextButton(onClick = { showEndDatePicker = false }) { Text(t("CANCEL", "ANNULLA", "ABBRECHEN", "ANNULER", "CANCELAR")) } }) { DatePicker(state) }
        }

        if (preview != null) {
            androidx.compose.ui.window.Dialog(onDismissRequest = { preview = null; previewScale = 1f }) {
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        AsyncImage(model = preview, contentDescription = "Enlarged photo — pinch to zoom", modifier = Modifier.fillMaxWidth().heightIn(max = 560.dp).graphicsLayer(scaleX = previewScale, scaleY = previewScale).transformable(previewTransform), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
                        TextButton(onClick = { preview = null; previewScale = 1f }) { Text(t("CLOSE", "CHIUDI", "SCHLIESSEN", "FERMER", "CERRAR")) }
                    }
                }
            }
        }
    }
}

private fun startOfDay(millis: Long?): Long? = millis?.let { Calendar.getInstance().apply { timeInMillis = it; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis }

private fun endOfDay(millis: Long?): Long? = millis?.let { Calendar.getInstance().apply { timeInMillis = it; set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }.timeInMillis }

private fun formatDate(millis: Long): String = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(java.util.Date(millis))

private fun loadAllPhotos(context: android.content.Context, startDate: Long?, endDate: Long?): List<Uri> {
    val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN, MediaStore.Images.Media.DATE_ADDED)
    val output = mutableListOf<Pair<Long, Uri>>()
    context.contentResolver.query(collection, projection, null, null, MediaStore.Images.Media.DATE_TAKEN + " DESC")?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
        val takenCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
        val addedCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_ADDED)
        while (cursor.moveToNext()) {
            val id = cursor.getLong(idCol)
            val taken = if (takenCol >= 0 && !cursor.isNull(takenCol)) cursor.getLong(takenCol) else 0L
            val added = if (addedCol >= 0 && !cursor.isNull(addedCol)) cursor.getLong(addedCol) * 1000L else 0L
            val timestamp = if (taken > 0) taken else added
            val inRange = (startDate == null || timestamp >= startDate) && (endDate == null || timestamp <= endDate)
            if (inRange) output.add(timestamp to Uri.withAppendedPath(collection, id.toString()))
        }
    }
    return output.sortedByDescending { it.first }.map { it.second }
}

private fun analyzePhotos(context: android.content.Context, uris: List<Uri>): List<PhotoScore> {
    val options = FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
        .build()
    val detector = FaceDetection.getClient(options)
    try {
        val candidates = uris.mapNotNull { uri ->
            val bitmap = loadBitmap(context.contentResolver.openInputStream(uri)) ?: return@mapNotNull null
            try {
                val faces = Tasks.await(detector.process(InputImage.fromBitmap(bitmap, 0)))
                val globalSharpness = calculateSharpness(bitmap)
                val globalBrightness = calculateBrightness(bitmap)
                val faceScores = faces.map { face ->
                    val box = face.boundingBox
                    val padX = (box.width() * 0.12f).toInt()
                    val padY = (box.height() * 0.12f).toInt()
                    val left = (box.left - padX).coerceIn(0, bitmap.width - 1)
                    val top = (box.top - padY).coerceIn(0, bitmap.height - 1)
                    val right = (box.right + padX).coerceIn(left + 1, bitmap.width)
                    val bottom = (box.bottom + padY).coerceIn(top + 1, bitmap.height)
                    val crop = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
                    val faceLighting = calculateFaceLighting(crop)
                    val faceSharp = calculateSharpness(crop)
                    crop.recycle()

                    val leftEye = face.leftEyeOpenProbability
                    val rightEye = face.rightEyeOpenProbability
                    val eyeScore = when {
                        leftEye == null && rightEye == null -> 65.0
                        leftEye != null && rightEye != null -> {
                            val weakerEye = minOf(leftEye, rightEye)
                            (weakerEye * 100.0).coerceIn(0.0, 100.0)
                        }
                        else -> ((leftEye ?: rightEye ?: 0.5f) * 85.0).coerceIn(0.0, 85.0)
                    }
                    // Face illumination is measured inside the face crop, not from the whole photo.
                    // The lower quartile and dark-pixel ratio help detect a face partly lost in shadow.
                    val meanLightScore = ((faceLighting.mean - 0.16) / 0.34 * 100.0).coerceIn(0.0, 100.0)
                    val lowerLightScore = ((faceLighting.lowerQuartile - 0.10) / 0.30 * 100.0).coerceIn(0.0, 100.0)
                    val shadowScore = (100.0 - faceLighting.shadowFraction * 190.0).coerceIn(0.0, 100.0)
                    val lightScore = (meanLightScore * 0.45 + lowerLightScore * 0.30 + shadowScore * 0.25).coerceIn(0.0, 100.0)
                    val sharpFaceScore = (sqrt(faceSharp.coerceAtLeast(0.0)) / 12.0 * 100.0).coerceIn(0.0, 100.0)
                    val smile = face.smilingProbability
                    // A natural/neutral expression remains valid; a detected smile is a small bonus only.
                    val expressionScore = if (smile == null) 75.0 else (75.0 + smile * 25.0).coerceIn(75.0, 100.0)
                    eyeScore * 0.35 + lightScore * 0.35 + sharpFaceScore * 0.20 + expressionScore * 0.10
                }
                val openEyes = faces.count { face ->
                    val l = face.leftEyeOpenProbability
                    val r = face.rightEyeOpenProbability
                    (l == null && r == null) || ((l ?: 0f) >= 0.45f && (r ?: 0f) >= 0.45f)
                }
                val globalSharpScore = (sqrt(globalSharpness.coerceAtLeast(0.0)) / 18.0 * 100.0).coerceIn(0.0, 100.0)
                val globalLightScore = (100.0 - abs(globalBrightness - 0.52) * 150.0).coerceIn(0.0, 100.0)
                val clippedFraction = calculateClippedFraction(bitmap)
                val exposurePenalty = when {
                    globalBrightness < 0.075 || globalBrightness > 0.94 -> 28.0
                    globalBrightness < 0.12 || globalBrightness > 0.88 -> 16.0
                    else -> 0.0
                } + (clippedFraction * 55.0).coerceAtMost(22.0)
                val blurPenalty = if (globalSharpScore < 18.0) 24.0 else if (globalSharpScore < 30.0) 12.0 else 0.0
                val closedEyeFaces = faces.count { face ->
                    val l = face.leftEyeOpenProbability
                    val r = face.rightEyeOpenProbability
                    l != null && r != null && l < 0.22f && r < 0.22f
                }
                val technicalRejected = globalSharpScore < 12.0 ||
                    globalBrightness < 0.045 || globalBrightness > 0.97 ||
                    (clippedFraction > 0.48 && (globalBrightness < 0.12 || globalBrightness > 0.88)) ||
                    (faces.isNotEmpty() && closedEyeFaces == faces.size)
                val overall = if (faceScores.isEmpty()) {
                    (globalSharpScore * 0.55 + globalLightScore * 0.45 - exposurePenalty - blurPenalty - if (technicalRejected) 35.0 else 0.0).coerceIn(0.0, 100.0)
                } else {
                    val averageFaces = faceScores.average()
                    val weakestFace = faceScores.minOrNull() ?: averageFaces
                    // Group photos are judged by everyone, not just the average: the weakest face
                    // receives half of the face-quality weight and very poor faces are penalized.
                    val groupFaces = averageFaces * 0.50 + weakestFace * 0.50
                    val severeSingleFacePenalty = when {
                        weakestFace < 30.0 -> (30.0 - weakestFace) * 0.90
                        weakestFace < 50.0 -> (50.0 - weakestFace) * 0.45
                        else -> 0.0
                    }
                    (globalSharpScore * 0.10 + globalLightScore * 0.05 + groupFaces * 0.85 - severeSingleFacePenalty - exposurePenalty - blurPenalty - if (technicalRejected) 35.0 else 0.0).coerceIn(0.0, 100.0)
                }
                val details = buildList {
                    add("${faces.size} faces detected")
                    if (faces.isNotEmpty()) add("$openEyes/${faces.size} faces with open/uncertain eyes")
                    add(if (globalSharpScore >= 60) "good overall sharpness" else "limited overall sharpness")
                    if (faceScores.isNotEmpty() && (faceScores.minOrNull() ?: 100.0) < 55.0) add("one face has weak lighting, focus or eyes")
                    add(if (globalLightScore >= 60) "balanced overall light" else "challenging overall light")
                    if (exposurePenalty > 12.0) add("technical warning: exposure/clipped highlights")
                    if (blurPenalty > 0.0) add("technical warning: possible blur")
                    if (technicalRejected) add("strong technical rejection flag")
                    if (faceScores.isNotEmpty() && (faceScores.minOrNull() ?: 100.0) < 45.0) add("reject from top shortlist: one face needs attention")
                }.joinToString(" • ")
                PhotoCandidate(
                    uri = uri,
                    score = overall.toInt().coerceIn(0, 100),
                    sharpness = globalSharpness,
                    brightness = globalBrightness,
                    faceCount = faces.size,
                    openEyes = openEyes,
                    timestampMs = readCaptureTime(context, uri),
                    sceneHash = calculateSceneHash(bitmap),
                    faceCenters = faces.map { face ->
                        Pair(face.boundingBox.centerX().toFloat() / bitmap.width, face.boundingBox.centerY().toFloat() / bitmap.height)
                    }.sortedBy { it.first },
                    technicalRejected = technicalRejected,
                    explanation = details
                )
            } finally {
                bitmap.recycle()
            }
        }

        // A sequence is grouped only if capture timestamps confirm <=60 seconds and
        // the visual hash indicates substantially the same framing/scene.
        val sorted = candidates.sortedBy { it.timestampMs ?: Long.MAX_VALUE }
        val groups = mutableListOf<MutableList<PhotoCandidate>>()
        for (candidate in sorted) {
            val time = candidate.timestampMs
            val matching = if (time == null) null else groups.firstOrNull { group ->
                val first = group.first()
                val firstTime = first.timestampMs
                firstTime != null && abs(time - firstTime) <= 60_000L &&
                    candidate.faceCount == first.faceCount &&
                    java.lang.Long.bitCount(candidate.sceneHash xor first.sceneHash) <= 18 &&
                    similarFaceLayout(candidate.faceCenters, first.faceCenters)
            }
            if (matching != null) matching.add(candidate) else groups.add(mutableListOf(candidate))
        }
        return groups.filter { it.size >= 2 }.flatMapIndexed { groupIndex, group ->
            val ranked = group.sortedWith(compareBy<PhotoCandidate> { it.technicalRejected }.thenByDescending { it.score })
            val winner = ranked.firstOrNull { !it.technicalRejected } ?: ranked.firstOrNull()
            ranked.mapIndexed { rankIndex, item ->
                PhotoScore(item.uri, item.score, item.sharpness, item.brightness, item.faceCount,
                    item.openEyes, groupIndex + 1, item.uri == winner?.uri,
                    rankIndex < 3 && !item.technicalRejected,
                    rankIndex + 1, item.technicalRejected, item.explanation)
            }
        }
    } finally {
        detector.close()
    }
}

private fun readCaptureTime(context: android.content.Context, uri: Uri): Long? {
    val mediaStoreTime = try {
        context.contentResolver.query(uri, arrayOf(MediaStore.Images.Media.DATE_TAKEN), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
                if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index).takeIf { it > 0L } else null
            } else null
        }
    } catch (_: Exception) { null }
    if (mediaStoreTime != null) return mediaStoreTime
    return try {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val exif = ExifInterface(stream)
            val date = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) ?: return@use null
            val offset = exif.getAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL)
            val parser = if (!offset.isNullOrBlank()) SimpleDateFormat("yyyy:MM:dd HH:mm:ssXXX", Locale.US)
                else SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
            parser.parse(if (!offset.isNullOrBlank()) date + offset else date)?.time
        }
    } catch (_: Exception) { null }
}

private fun similarFaceLayout(a: List<Pair<Float, Float>>, b: List<Pair<Float, Float>>): Boolean {
    if (a.size != b.size) return false
    if (a.isEmpty()) return true
    return a.zip(b).all { (left, right) ->
        val dx = left.first - right.first
        val dy = left.second - right.second
        dx * dx + dy * dy <= 0.18f * 0.18f
    }
}

private fun calculateSceneHash(bitmap: Bitmap): Long {
    val sample = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
    val gray = IntArray(9 * 8)
    for (y in 0 until 8) for (x in 0 until 9) {
        val p = sample.getPixel(x, y)
        val r = (p shr 16 and 0xff)
        val g = (p shr 8 and 0xff)
        val b = (p and 0xff)
        gray[y * 9 + x] = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
    }
    sample.recycle()
    var hash = 0L
    var bit = 0
    for (y in 0 until 8) for (x in 0 until 8) {
        if (gray[y * 9 + x] > gray[y * 9 + x + 1]) hash = hash or (1L shl bit)
        bit++
    }
    return hash
}

private fun loadBitmap(stream: InputStream?): Bitmap? {
    if (stream == null) return null
    return stream.use { input ->
        val bytes = input.readBytes()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }
}


private fun calculateFaceLighting(bitmap: Bitmap): FaceLightingStats {
    // Ignore a narrow border around the detector box, where hair and background can distort
    // the measurement. Sample the central face area and inspect its darker quarter as well.
    val left = (bitmap.width * 0.12f).toInt().coerceIn(0, bitmap.width - 1)
    val top = (bitmap.height * 0.12f).toInt().coerceIn(0, bitmap.height - 1)
    val right = (bitmap.width * 0.88f).toInt().coerceIn(left + 1, bitmap.width)
    val bottom = (bitmap.height * 0.88f).toInt().coerceIn(top + 1, bitmap.height)
    val stepX = ((right - left) / 48).coerceAtLeast(1)
    val stepY = ((bottom - top) / 48).coerceAtLeast(1)
    val samples = ArrayList<Double>()
    for (y in top until bottom step stepY) {
        for (x in left until right step stepX) {
            val p = bitmap.getPixel(x, y)
            val r = (p shr 16 and 0xff) / 255.0
            val g = (p shr 8 and 0xff) / 255.0
            val b = (p and 0xff) / 255.0
            samples.add(0.2126 * r + 0.7152 * g + 0.0722 * b)
        }
    }
    if (samples.isEmpty()) return FaceLightingStats(0.5, 0.35, 0.0)
    samples.sort()
    val mean = samples.average()
    val lowerQuartile = samples[(samples.size * 0.25).toInt().coerceIn(0, samples.lastIndex)]
    val shadowFraction = samples.count { it < 0.18 }.toDouble() / samples.size
    return FaceLightingStats(mean, lowerQuartile, shadowFraction)
}

private fun calculateClippedFraction(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 100).coerceAtLeast(1)
    val stepY = (bitmap.height / 100).coerceAtLeast(1)
    var clipped = 0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16) and 0xff
            val g = (pixel shr 8) and 0xff
            val b = pixel and 0xff
            val luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
            if (luminance < 12.0 || luminance > 248.0) clipped++
            count++
        }
    }
    return if (count == 0) 0.0 else clipped.toDouble() / count
}

private fun calculateBrightness(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 80).coerceAtLeast(1)
    val stepY = (bitmap.height / 80).coerceAtLeast(1)
    var sum = 0.0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16 and 0xff) / 255.0
            val g = (pixel shr 8 and 0xff) / 255.0
            val b = (pixel and 0xff) / 255.0
            sum += 0.2126 * r + 0.7152 * g + 0.0722 * b
            count++
        }
    }
    return if (count == 0) 0.5 else sum / count
}

private fun calculateSharpness(bitmap: Bitmap): Double {
    val scale = minOf(1.0, 240.0 / maxOf(bitmap.width, bitmap.height))
    val w = (bitmap.width * scale).toInt().coerceAtLeast(3)
    val h = (bitmap.height * scale).toInt().coerceAtLeast(3)
    val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
    val values = DoubleArray(w * h)
    for (y in 0 until h) for (x in 0 until w) {
        val p = small.getPixel(x, y)
        val r = (p shr 16 and 0xff).toDouble()
        val g = (p shr 8 and 0xff).toDouble()
        val b = (p and 0xff).toDouble()
        values[y * w + x] = 0.299 * r + 0.587 * g + 0.114 * b
    }
    var sum = 0.0
    var sumSq = 0.0
    var count = 0
    for (y in 1 until h - 1) for (x in 1 until w - 1) {
        val i = y * w + x
        val lap = values[i - w] + values[i - 1] - 4 * values[i] + values[i + 1] + values[i + w]
        sum += lap
        sumSq += lap * lap
        count++
    }
    small.recycle()
    if (count == 0) return 0.0
    val mean = sum / count
    return (sumSq / count - mean * mean).coerceAtLeast(0.0)
}

@Composable
private fun ChoiceCard(
    title: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    selected: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) Blue else Color(0xFFDCEAF2)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFEAF6FC), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Ink.copy(alpha = .62f), fontSize = 11.sp)
            }
            RadioButton(selected = selected, onClick = onClick)
        }
    }
}
