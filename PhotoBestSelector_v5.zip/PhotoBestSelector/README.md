# PhotoBestSelector

Android photo-sequence selector. Build with Java 17 and Gradle 8.9 using `gradle assembleDebug`.

## v4 changes
- Kept the main screen vertically scrollable and portrait-only.
- Added an explicit **Confirm Dates & Search** action. Selecting dates alone does not start a gallery search.
- Added pinch-to-zoom to the enlarged-photo dialog.
- Analysis results now omit groups containing only one photo; only groups with at least two visually/time-matched candidates are returned.

The GitHub Actions workflow is unchanged. Keep this ZIP as the only source ZIP in the repository when uploading it.
