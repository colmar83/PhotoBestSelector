# PhotoBestSelector

Android app project. Default interface language: English; Italian, German, French and Spanish can be selected in the top bar.

## User interface in this build

- One main screen: choose multiple photos, analyze them, and review all analyzed photos in one continuous list. The app does not create separate browsing screens for photo sequences.
- The best candidates from detected sequences are shown together in a horizontal shortlist. Tap a candidate or any photo to open a larger preview.
- A star marks/unmarks a favorite; favorites and the selected interface language are stored on the device.
- Original photos are never edited or deleted.

## Analysis and limitations

Analysis runs locally on the device. The current scoring engine assesses detected faces separately using eye-open probabilities, face-region sharpness, a limited smile cue, and a face-lighting estimate based on mean luminance, the darker quarter of face pixels, and the proportion of very dark pixels. Group scoring gives the weakest face half of the face-quality weight and adds a penalty to very weak individual faces.

Sequence detection is heuristic: capture time must be available and within 60 seconds, face count/layout must match, and a visual composition hash must be sufficiently similar. If capture time cannot be read, a photo is kept separate rather than guessed into a sequence.

This is not a trained aesthetic model. It cannot reliably judge artistic composition, distracting objects, posture, hands/feet, emotional authenticity, or the decisive moment. Face detection and brightness estimates can also fail with shadows, occlusion, profiles, color casts, and inaccurate face crops. Treat the shortlist as assistance, not as an infallible verdict. The app does not automatically discard or delete photos.

## Build and stable updates

- `applicationId` remains `com.photobestselector.app`.
- Debug APKs are signed with the persistent keystore at `signing/debug.keystore`.
- CI build numbers increase `versionCode` automatically.
- Keep this keystore unchanged and keep the repository private. Losing or replacing it prevents Android from accepting future APK updates over an installation signed with this key.
- If the currently installed APK was signed with a different key, Android may require one uninstall for migration. After installing a build signed with this persistent key, keep using the same key.
