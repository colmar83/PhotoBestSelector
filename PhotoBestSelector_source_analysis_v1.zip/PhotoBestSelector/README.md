# PhotoBestSelector

Android app project. Default interface language: English.

## Build
Open with Android Studio (JDK 17, Android SDK 35) or run:

```bash
./gradlew assembleDebug
```

The first milestone is the app shell and manual photo selection. The smart sequence grouping, date-range scan, scoring, results, trash/recovery, and translations are planned implementation stages and are not yet implemented in this starter build.

## Core product rule
Only compare photos from a short sequence (about 60 seconds) when the same subjects, scene, arrangement, and framing remain substantially the same. Do not group merely because photos are visually similar or close in time.
