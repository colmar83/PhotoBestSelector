package com.photobestselector.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import android.net.Uri

private val Ink = Color(0xFF18324A)
private val Blue = Color(0xFF2686C9)
private val Green = Color(0xFF19A66A)
private val Pale = Color(0xFFF3FAFE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoBestSelectorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoBestSelectorApp() {
    var selected by remember { mutableStateOf("gallery") }
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var status by remember { mutableStateOf("Choose how you want to select your photos.") }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(200)
    ) { uris ->
        photos = uris
        if (uris.isNotEmpty()) status = "${uris.size} photos selected. Analysis engine is the next development step."
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            secondary = Green,
            background = Pale,
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PhotoBestSelector", fontWeight = FontWeight.Bold, color = Ink)
                            Text("Find Your Perfect Shot.", fontSize = 12.sp, color = Blue)
                        }
                    },
                    actions = {
                        IconButton(onClick = { status = "Settings and language selection will be added in the next interface step." }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Ink)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(18.dp))
                Box(
                    modifier = Modifier.fillMaxWidth().height(154.dp)
                        .background(Color(0xFFE1F2FB), RoundedCornerShape(26.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📸", fontSize = 48.sp)
                        Text("Many photos. One winner.", color = Ink, fontWeight = FontWeight.SemiBold)
                        Text("Find the best moment in every photo sequence.", color = Ink.copy(alpha = .7f), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text("SELECT YOUR PHOTOS", color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                ChoiceCard(
                    title = "Analyze entire gallery",
                    subtitle = "Find eligible photo sequences in your library",
                    icon = { Icon(Icons.Default.PhotoLibrary, null, tint = Blue) },
                    selected = selected == "gallery",
                    onClick = { selected = "gallery"; status = "Gallery-wide analysis will be enabled with the on-device analysis engine." }
                )
                Spacer(Modifier.height(10.dp))
                ChoiceCard(
                    title = "Choose a date range",
                    subtitle = "Analyze photos taken between two dates",
                    icon = { Icon(Icons.Default.CalendarMonth, null, tint = Blue) },
                    selected = selected == "dates",
                    onClick = { selected = "dates"; status = "Date-range selection will be added in the next interface step." }
                )
                Spacer(Modifier.height(10.dp))
                ChoiceCard(
                    title = "Select photos manually",
                    subtitle = "Choose the photos you want to compare",
                    icon = { Icon(Icons.Default.Collections, null, tint = Blue) },
                    selected = selected == "manual",
                    onClick = { selected = "manual"; picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                )
                if (photos.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text("${photos.size} photos selected", color = Green, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(photos) { uri ->
                            AsyncImage(model = uri, contentDescription = "Selected photo",
                                modifier = Modifier.size(66.dp).background(Color.LightGray, RoundedCornerShape(10.dp)))
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        status = when {
                            selected == "manual" && photos.isEmpty() -> "Please select photos first."
                            selected == "manual" -> "Ready: ${photos.size} photos selected. Smart sequence analysis is not yet implemented."
                            selected == "dates" -> "Date-range selection is coming in the next development step."
                            else -> "Gallery analysis will be connected to the smart on-device engine in the next development step."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Text("START ANALYSIS", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(12.dp))
                Text(status, color = Ink.copy(alpha = .72f), fontSize = 12.sp, lineHeight = 17.sp)
                Spacer(Modifier.weight(1f))
                Text("Private by design • Your original photos stay untouched", color = Ink.copy(alpha = .55f), fontSize = 11.sp)
                Spacer(Modifier.height(14.dp))
            }
        }
    }
}

@Composable
private fun ChoiceCard(
    title: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    selected: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) Blue else Color(0xFFDCEAF2)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFEAF6FC), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Ink.copy(alpha = .62f), fontSize = 11.sp)
            }
            RadioButton(selected = selected, onClick = onClick)
        }
    }
}
