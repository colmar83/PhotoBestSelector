# PhotoBestSelector

Android app project. Default interface language: English.

## Build and stable updates

- `applicationId` remains `com.photobestselector.app`.
- Debug APKs are signed with the persistent keystore at `signing/debug.keystore`.
- CI build numbers increase `versionCode` automatically, so later APKs can update earlier builds.
- Keep this keystore unchanged and keep the repository private. Losing or replacing it prevents Android from accepting future APK updates over an installation signed with this key.
- The first installation signed with this permanent key may require uninstalling an older APK signed with a different temporary key. After that migration, keep using this same keystore for every release.

## Current analysis milestone

Manual photo selection and on-device analysis are implemented. The scoring engine assesses each detected face separately using eye-open probabilities, face-region sharpness, a limited expression cue, and a face-lighting estimate based on mean luminance, the darker quarter of face pixels, and the proportion of very dark pixels. Group scoring gives the weakest face half of the face-quality weight and applies an additional penalty to very weak individual faces. This improves detection of faces lost in shadow, but remains a heuristic and can be affected by skin tone, strong color casts, occlusion, and detector crop accuracy.

Photos are grouped as the same sequence only when capture time is available and within 60 seconds, face count/layout is consistent, and a visual composition hash is sufficiently similar. If capture time cannot be read, the app deliberately keeps that photo separate rather than guessing. This is an initial heuristic: it is not a trained aesthetic model and can still make mistakes, especially with difficult lighting, occlusions, profile faces, or major camera movement.

Original photos are not modified or deleted. Analysis runs on the device.
