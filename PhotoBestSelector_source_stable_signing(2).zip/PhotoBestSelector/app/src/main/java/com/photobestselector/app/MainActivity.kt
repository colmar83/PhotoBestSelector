package com.photobestselector.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.text.SimpleDateFormat
import java.util.Locale
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import kotlin.math.abs
import kotlin.math.sqrt

private val Ink = Color(0xFF18324A)
private val Blue = Color(0xFF2686C9)
private val Green = Color(0xFF19A66A)
private val Pale = Color(0xFFF3FAFE)

private data class FaceLightingStats(
    val mean: Double,
    val lowerQuartile: Double,
    val shadowFraction: Double
)

private data class PhotoScore(
    val uri: Uri,
    val score: Int,
    val sharpness: Double,
    val brightness: Double,
    val faceCount: Int,
    val openEyes: Int,
    val groupNumber: Int,
    val isGroupBest: Boolean,
    val explanation: String
)

private data class PhotoCandidate(
    val uri: Uri,
    val score: Int,
    val sharpness: Double,
    val brightness: Double,
    val faceCount: Int,
    val openEyes: Int,
    val timestampMs: Long?,
    val sceneHash: Long,
    val faceCenters: List<Pair<Float, Float>>,
    val explanation: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoBestSelectorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoBestSelectorApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf("gallery") }
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var status by remember { mutableStateOf("Choose how you want to select your photos.") }
    var analyzing by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<PhotoScore>>(emptyList()) }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(200)
    ) { uris ->
        photos = uris
        results = emptyList()
        if (uris.isNotEmpty()) status = "${uris.size} photos selected. Ready to compare."
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, secondary = Green, background = Pale,
            surface = Color.White, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PhotoBestSelector", fontWeight = FontWeight.Bold, color = Ink)
                            Text("Find Your Perfect Shot.", fontSize = 12.sp, color = Blue)
                        }
                    },
                    actions = {
                        IconButton(onClick = { status = "Settings and language selection will be added in a later update." }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Ink)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(18.dp))
                Box(
                    modifier = Modifier.fillMaxWidth().height(154.dp)
                        .background(Color(0xFFE1F2FB), RoundedCornerShape(26.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📸", fontSize = 48.sp)
                        Text("Many photos. One winner.", color = Ink, fontWeight = FontWeight.SemiBold)
                        Text("Find the best moment in every photo sequence.", color = Ink.copy(alpha = .7f), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text("SELECT YOUR PHOTOS", color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                ChoiceCard(
                    title = "Analyze entire gallery",
                    subtitle = "Find eligible photo sequences in your library",
                    icon = { Icon(Icons.Default.PhotoLibrary, null, tint = Blue) },
                    selected = selected == "gallery",
                    onClick = { selected = "gallery"; results = emptyList(); status = "Gallery-wide analysis will be added after manual photo comparison." }
                )
                Spacer(Modifier.height(10.dp))
                ChoiceCard(
                    title = "Choose a date range",
                    subtitle = "Analyze photos taken between two dates",
                    icon = { Icon(Icons.Default.CalendarMonth, null, tint = Blue) },
                    selected = selected == "dates",
                    onClick = { selected = "dates"; results = emptyList(); status = "Date-range selection will be added in a later update." }
                )
                Spacer(Modifier.height(10.dp))
                ChoiceCard(
                    title = "Select photos manually",
                    subtitle = "Choose the photos you want to compare",
                    icon = { Icon(Icons.Default.Collections, null, tint = Blue) },
                    selected = selected == "manual",
                    onClick = { selected = "manual"; results = emptyList(); picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                )
                if (photos.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text("${photos.size} photos selected", color = Green, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(photos) { uri ->
                            AsyncImage(model = uri, contentDescription = "Selected photo",
                                modifier = Modifier.size(66.dp).background(Color.LightGray, RoundedCornerShape(10.dp)))
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    enabled = !analyzing,
                    onClick = {
                        when {
                            selected == "manual" && photos.isEmpty() -> status = "Please select photos first."
                            selected == "manual" -> {
                                analyzing = true
                                results = emptyList()
                                status = "Analyzing ${photos.size} photos on this device..."
                                scope.launch {
                                    try {
                                        val scored = withContext(Dispatchers.IO) { analyzePhotos(context, photos) }
                                        results = scored.sortedByDescending { it.score }
                                        status = if (scored.isNotEmpty()) "Analysis complete. The highest-scoring photo is your suggested shot." else "No readable photos were found. Please select them again."
                                    } catch (e: Exception) {
                                        status = "Analysis could not be completed. Please try selecting the photos again."
                                    } finally {
                                        analyzing = false
                                    }
                                }
                            }
                            selected == "dates" -> status = "Date-range selection is coming in a later update."
                            else -> status = "Please choose Select photos manually to compare selected photos."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    if (analyzing) CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                    else Text("START ANALYSIS", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(12.dp))
                Text(status, color = Ink.copy(alpha = .72f), fontSize = 12.sp, lineHeight = 17.sp)

                if (results.isNotEmpty()) {
                    Spacer(Modifier.height(18.dp))
                    Text("ANALYSIS RESULTS", color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    // Quick second pass: show the strongest 1–3 candidates of each detected burst
                    // side by side, without deleting or modifying any original image.
                    results.groupBy { it.groupNumber }.toSortedMap().forEach { (groupNumber, groupItems) ->
                        Text("GROUP $groupNumber • FINALISTS", color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.height(5.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            items(groupItems.sortedByDescending { it.score }.take(3)) { finalist ->
                                Column(
                                    modifier = Modifier.width(116.dp)
                                        .background(Color.White, RoundedCornerShape(12.dp))
                                        .padding(7.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    AsyncImage(model = finalist.uri, contentDescription = "Finalist photo",
                                        modifier = Modifier.fillMaxWidth().height(88.dp).background(Color.LightGray, RoundedCornerShape(8.dp)),
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                    Text("${finalist.score}/100", color = if (finalist.isGroupBest) Green else Ink,
                                        fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(if (finalist.isGroupBest) "BEST" else "KEEP IN VIEW", color = Ink.copy(alpha = .65f), fontSize = 9.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                    Text("FULL RANKING", color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    results.forEachIndexed { index, item ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = androidx.compose.foundation.BorderStroke(if (index == 0) 2.dp else 1.dp, if (index == 0) Green else Color(0xFFDCEAF2))
                        ) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(model = item.uri, contentDescription = "Analyzed photo", modifier = Modifier.size(86.dp).background(Color.LightGray, RoundedCornerShape(10.dp)))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(if (item.isGroupBest) "GROUP ${item.groupNumber} • SUGGESTED BEST PHOTO" else "Group ${item.groupNumber} • Photo", color = if (item.isGroupBest) Green else Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("Score: ${item.score}/100", color = Ink, fontWeight = FontWeight.SemiBold)
                                    Text(item.explanation, color = Ink.copy(alpha = .7f), fontSize = 11.sp, lineHeight = 15.sp)
                                }
                            }
                        }
                    }
                    Text("Three-pass review: (1) technical quality and exposure, (2) side-by-side comparison of up to three finalists per burst, (3) eyes, expression and group balance. Originals are never deleted. The app can estimate blur, exposure and face quality; it does not yet reliably understand body posture, hands/feet, distracting objects or the artistic decisive moment. Photos are grouped only when capture times are within 60 seconds and visual composition is sufficiently similar.", color = Ink.copy(alpha = .58f), fontSize = 11.sp, lineHeight = 15.sp)
                }
                Spacer(Modifier.height(12.dp))
                Text("Private by design • Your original photos stay untouched", color = Ink.copy(alpha = .55f), fontSize = 11.sp)
                Spacer(Modifier.height(14.dp))
            }
        }
    }
}

private fun analyzePhotos(context: android.content.Context, uris: List<Uri>): List<PhotoScore> {
    val options = FaceDetectorOptions.Builder()
        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
        .build()
    val detector = FaceDetection.getClient(options)
    try {
        val candidates = uris.mapNotNull { uri ->
            val bitmap = loadBitmap(context.contentResolver.openInputStream(uri)) ?: return@mapNotNull null
            try {
                val faces = Tasks.await(detector.process(InputImage.fromBitmap(bitmap, 0)))
                val globalSharpness = calculateSharpness(bitmap)
                val globalBrightness = calculateBrightness(bitmap)
                val faceScores = faces.map { face ->
                    val box = face.boundingBox
                    val padX = (box.width() * 0.12f).toInt()
                    val padY = (box.height() * 0.12f).toInt()
                    val left = (box.left - padX).coerceIn(0, bitmap.width - 1)
                    val top = (box.top - padY).coerceIn(0, bitmap.height - 1)
                    val right = (box.right + padX).coerceIn(left + 1, bitmap.width)
                    val bottom = (box.bottom + padY).coerceIn(top + 1, bitmap.height)
                    val crop = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
                    val faceLighting = calculateFaceLighting(crop)
                    val faceSharp = calculateSharpness(crop)
                    crop.recycle()

                    val leftEye = face.leftEyeOpenProbability
                    val rightEye = face.rightEyeOpenProbability
                    val eyeScore = when {
                        leftEye == null && rightEye == null -> 65.0
                        leftEye != null && rightEye != null -> {
                            val weakerEye = minOf(leftEye, rightEye)
                            (weakerEye * 100.0).coerceIn(0.0, 100.0)
                        }
                        else -> ((leftEye ?: rightEye ?: 0.5f) * 85.0).coerceIn(0.0, 85.0)
                    }
                    // Face illumination is measured inside the face crop, not from the whole photo.
                    // The lower quartile and dark-pixel ratio help detect a face partly lost in shadow.
                    val meanLightScore = ((faceLighting.mean - 0.16) / 0.34 * 100.0).coerceIn(0.0, 100.0)
                    val lowerLightScore = ((faceLighting.lowerQuartile - 0.10) / 0.30 * 100.0).coerceIn(0.0, 100.0)
                    val shadowScore = (100.0 - faceLighting.shadowFraction * 190.0).coerceIn(0.0, 100.0)
                    val lightScore = (meanLightScore * 0.45 + lowerLightScore * 0.30 + shadowScore * 0.25).coerceIn(0.0, 100.0)
                    val sharpFaceScore = (sqrt(faceSharp.coerceAtLeast(0.0)) / 12.0 * 100.0).coerceIn(0.0, 100.0)
                    val smile = face.smilingProbability
                    // A natural/neutral expression remains valid; a detected smile is a small bonus only.
                    val expressionScore = if (smile == null) 75.0 else (75.0 + smile * 25.0).coerceIn(75.0, 100.0)
                    eyeScore * 0.35 + lightScore * 0.35 + sharpFaceScore * 0.20 + expressionScore * 0.10
                }
                val openEyes = faces.count { face ->
                    val l = face.leftEyeOpenProbability
                    val r = face.rightEyeOpenProbability
                    (l == null && r == null) || ((l ?: 0f) >= 0.45f && (r ?: 0f) >= 0.45f)
                }
                val globalSharpScore = (sqrt(globalSharpness.coerceAtLeast(0.0)) / 18.0 * 100.0).coerceIn(0.0, 100.0)
                val globalLightScore = (100.0 - abs(globalBrightness - 0.52) * 150.0).coerceIn(0.0, 100.0)
                val clippedFraction = calculateClippedFraction(bitmap)
                val exposurePenalty = when {
                    globalBrightness < 0.075 || globalBrightness > 0.94 -> 28.0
                    globalBrightness < 0.12 || globalBrightness > 0.88 -> 16.0
                    else -> 0.0
                } + (clippedFraction * 55.0).coerceAtMost(22.0)
                val blurPenalty = if (globalSharpScore < 18.0) 24.0 else if (globalSharpScore < 30.0) 12.0 else 0.0
                val overall = if (faceScores.isEmpty()) {
                    (globalSharpScore * 0.55 + globalLightScore * 0.45 - exposurePenalty - blurPenalty).coerceIn(0.0, 100.0)
                } else {
                    val averageFaces = faceScores.average()
                    val weakestFace = faceScores.minOrNull() ?: averageFaces
                    // Group photos are judged by everyone, not just the average: the weakest face
                    // receives half of the face-quality weight and very poor faces are penalized.
                    val groupFaces = averageFaces * 0.50 + weakestFace * 0.50
                    val severeSingleFacePenalty = when {
                        weakestFace < 30.0 -> (30.0 - weakestFace) * 0.90
                        weakestFace < 50.0 -> (50.0 - weakestFace) * 0.45
                        else -> 0.0
                    }
                    (globalSharpScore * 0.10 + globalLightScore * 0.05 + groupFaces * 0.85 - severeSingleFacePenalty - exposurePenalty - blurPenalty).coerceIn(0.0, 100.0)
                }
                val details = buildList {
                    add("${faces.size} faces detected")
                    if (faces.isNotEmpty()) add("$openEyes/${faces.size} faces with open/uncertain eyes")
                    add(if (globalSharpScore >= 60) "good overall sharpness" else "limited overall sharpness")
                    if (faceScores.isNotEmpty() && (faceScores.minOrNull() ?: 100.0) < 55.0) add("one face has weak lighting, focus or eyes")
                    add(if (globalLightScore >= 60) "balanced overall light" else "challenging overall light")
                    if (exposurePenalty > 12.0) add("technical warning: exposure/clipped highlights")
                    if (blurPenalty > 0.0) add("technical warning: possible blur")
                    if (faceScores.isNotEmpty() && (faceScores.minOrNull() ?: 100.0) < 45.0) add("reject from top shortlist: one face needs attention")
                }.joinToString(" • ")
                PhotoCandidate(
                    uri = uri,
                    score = overall.toInt().coerceIn(0, 100),
                    sharpness = globalSharpness,
                    brightness = globalBrightness,
                    faceCount = faces.size,
                    openEyes = openEyes,
                    timestampMs = readCaptureTime(context, uri),
                    sceneHash = calculateSceneHash(bitmap),
                    faceCenters = faces.map { face ->
                        Pair(face.boundingBox.centerX().toFloat() / bitmap.width, face.boundingBox.centerY().toFloat() / bitmap.height)
                    }.sortedBy { it.first },
                    explanation = details
                )
            } finally {
                bitmap.recycle()
            }
        }

        // A sequence is grouped only if capture timestamps confirm <=60 seconds and
        // the visual hash indicates substantially the same framing/scene.
        val sorted = candidates.sortedBy { it.timestampMs ?: Long.MAX_VALUE }
        val groups = mutableListOf<MutableList<PhotoCandidate>>()
        for (candidate in sorted) {
            val time = candidate.timestampMs
            val matching = if (time == null) null else groups.firstOrNull { group ->
                val first = group.first()
                val firstTime = first.timestampMs
                firstTime != null && abs(time - firstTime) <= 60_000L &&
                    candidate.faceCount == first.faceCount &&
                    java.lang.Long.bitCount(candidate.sceneHash xor first.sceneHash) <= 18 &&
                    similarFaceLayout(candidate.faceCenters, first.faceCenters)
            }
            if (matching != null) matching.add(candidate) else groups.add(mutableListOf(candidate))
        }
        return groups.flatMapIndexed { groupIndex, group ->
            val winner = group.maxByOrNull { it.score }
            group.sortedByDescending { it.score }.map { item ->
                PhotoScore(item.uri, item.score, item.sharpness, item.brightness, item.faceCount,
                    item.openEyes, groupIndex + 1, item.uri == winner?.uri, item.explanation)
            }
        }
    } finally {
        detector.close()
    }
}

private fun readCaptureTime(context: android.content.Context, uri: Uri): Long? {
    val mediaStoreTime = try {
        context.contentResolver.query(uri, arrayOf(MediaStore.Images.Media.DATE_TAKEN), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
                if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index).takeIf { it > 0L } else null
            } else null
        }
    } catch (_: Exception) { null }
    if (mediaStoreTime != null) return mediaStoreTime
    return try {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val exif = ExifInterface(stream)
            val date = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) ?: return@use null
            val offset = exif.getAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL)
            val parser = if (!offset.isNullOrBlank()) SimpleDateFormat("yyyy:MM:dd HH:mm:ssXXX", Locale.US)
                else SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
            parser.parse(if (!offset.isNullOrBlank()) date + offset else date)?.time
        }
    } catch (_: Exception) { null }
}

private fun similarFaceLayout(a: List<Pair<Float, Float>>, b: List<Pair<Float, Float>>): Boolean {
    if (a.size != b.size) return false
    if (a.isEmpty()) return true
    return a.zip(b).all { (left, right) ->
        val dx = left.first - right.first
        val dy = left.second - right.second
        dx * dx + dy * dy <= 0.18f * 0.18f
    }
}

private fun calculateSceneHash(bitmap: Bitmap): Long {
    val sample = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
    val gray = IntArray(9 * 8)
    for (y in 0 until 8) for (x in 0 until 9) {
        val p = sample.getPixel(x, y)
        val r = (p shr 16 and 0xff)
        val g = (p shr 8 and 0xff)
        val b = (p and 0xff)
        gray[y * 9 + x] = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
    }
    sample.recycle()
    var hash = 0L
    var bit = 0
    for (y in 0 until 8) for (x in 0 until 8) {
        if (gray[y * 9 + x] > gray[y * 9 + x + 1]) hash = hash or (1L shl bit)
        bit++
    }
    return hash
}

private fun loadBitmap(stream: InputStream?): Bitmap? {
    if (stream == null) return null
    return stream.use { input ->
        val bytes = input.readBytes()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }
}


private fun calculateFaceLighting(bitmap: Bitmap): FaceLightingStats {
    // Ignore a narrow border around the detector box, where hair and background can distort
    // the measurement. Sample the central face area and inspect its darker quarter as well.
    val left = (bitmap.width * 0.12f).toInt().coerceIn(0, bitmap.width - 1)
    val top = (bitmap.height * 0.12f).toInt().coerceIn(0, bitmap.height - 1)
    val right = (bitmap.width * 0.88f).toInt().coerceIn(left + 1, bitmap.width)
    val bottom = (bitmap.height * 0.88f).toInt().coerceIn(top + 1, bitmap.height)
    val stepX = ((right - left) / 48).coerceAtLeast(1)
    val stepY = ((bottom - top) / 48).coerceAtLeast(1)
    val samples = ArrayList<Double>()
    for (y in top until bottom step stepY) {
        for (x in left until right step stepX) {
            val p = bitmap.getPixel(x, y)
            val r = (p shr 16 and 0xff) / 255.0
            val g = (p shr 8 and 0xff) / 255.0
            val b = (p and 0xff) / 255.0
            samples.add(0.2126 * r + 0.7152 * g + 0.0722 * b)
        }
    }
    if (samples.isEmpty()) return FaceLightingStats(0.5, 0.35, 0.0)
    samples.sort()
    val mean = samples.average()
    val lowerQuartile = samples[(samples.size * 0.25).toInt().coerceIn(0, samples.lastIndex)]
    val shadowFraction = samples.count { it < 0.18 }.toDouble() / samples.size
    return FaceLightingStats(mean, lowerQuartile, shadowFraction)
}

private fun calculateClippedFraction(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 100).coerceAtLeast(1)
    val stepY = (bitmap.height / 100).coerceAtLeast(1)
    var clipped = 0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16) and 0xff
            val g = (pixel shr 8) and 0xff
            val b = pixel and 0xff
            val luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
            if (luminance < 12.0 || luminance > 248.0) clipped++
            count++
        }
    }
    return if (count == 0) 0.0 else clipped.toDouble() / count
}

private fun calculateBrightness(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 80).coerceAtLeast(1)
    val stepY = (bitmap.height / 80).coerceAtLeast(1)
    var sum = 0.0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16 and 0xff) / 255.0
            val g = (pixel shr 8 and 0xff) / 255.0
            val b = (pixel and 0xff) / 255.0
            sum += 0.2126 * r + 0.7152 * g + 0.0722 * b
            count++
        }
    }
    return if (count == 0) 0.5 else sum / count
}

private fun calculateSharpness(bitmap: Bitmap): Double {
    val scale = minOf(1.0, 240.0 / maxOf(bitmap.width, bitmap.height))
    val w = (bitmap.width * scale).toInt().coerceAtLeast(3)
    val h = (bitmap.height * scale).toInt().coerceAtLeast(3)
    val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
    val values = DoubleArray(w * h)
    for (y in 0 until h) for (x in 0 until w) {
        val p = small.getPixel(x, y)
        val r = (p shr 16 and 0xff).toDouble()
        val g = (p shr 8 and 0xff).toDouble()
        val b = (p and 0xff).toDouble()
        values[y * w + x] = 0.299 * r + 0.587 * g + 0.114 * b
    }
    var sum = 0.0
    var sumSq = 0.0
    var count = 0
    for (y in 1 until h - 1) for (x in 1 until w - 1) {
        val i = y * w + x
        val lap = values[i - w] + values[i - 1] - 4 * values[i] + values[i + 1] + values[i + w]
        sum += lap
        sumSq += lap * lap
        count++
    }
    small.recycle()
    if (count == 0) return 0.0
    val mean = sum / count
    return (sumSq / count - mean * mean).coerceAtLeast(0.0)
}

@Composable
private fun ChoiceCard(
    title: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    selected: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) Blue else Color(0xFFDCEAF2)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFEAF6FC), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Ink.copy(alpha = .62f), fontSize = 11.sp)
            }
            RadioButton(selected = selected, onClick = onClick)
        }
    }
}
