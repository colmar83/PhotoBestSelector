# PhotoBestSelector

Professional Android photo culling prototype.

## Sequence-first selection
- A valid sequence must contain at least 2 photos.
- Photos must belong to the same visual situation/subjects and be captured within a maximum 60-second window.
- Single photos and unrelated scenes are excluded from the results.
- Exactly one winner is shown for each valid sequence.
- The winner includes a concise explanation of why it was selected.
- All photos belonging to a valid sequence remain available for comparison.
- The comparison viewer supports pinch-to-zoom, left/right swipe, and previous/next arrow buttons.
- Originals are never deleted.

## Languages
English, Italian, German, French and Spanish.

## Build
Java 17 / Gradle 8.9 / Android SDK 35.
