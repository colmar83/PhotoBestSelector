# PhotoBestSelector

Professional-style local photo culling assistant for Android.

## Current workflow
- Choose individual photos, select all photos, or filter the gallery by start/end date.
- Analyze on-device using technical quality, per-face quality, scene consistency and capture time.
- Technical screening considers sharpness/focus, exposure/clipping, eye openness and an image-noise estimate.
- For multi-person images, face quality is evaluated separately and the weakest face is strongly penalized so one poorly captured person cannot be hidden by a high average score.
- Similar sequences are detected only when capture time and visual/face layout are sufficiently consistent.
- The app selects one overall winner and explains the main reasons.
- All other photos remain available and are never deleted.
- Open any image full-screen, swipe or use arrows to move between images, and pinch to zoom up to 5x.
- Favorites are saved locally.
- UI languages: English, Italian, German, French and Spanish.
- Portrait orientation only.

## Important limitation
The app uses public, on-device computer-vision signals. It does not reproduce proprietary Apple Photos, Google Photos or Adobe Lightroom models. Posture, scene aesthetics and emotional impact are treated as supporting signals rather than claimed to be infallible AI judgments.

## Build
GitHub Actions builds the debug APK with JDK 17 and Gradle 8.9.
