package com.photobestselector.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import coil.compose.AsyncImage
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

private val Ink = Color(0xFF18324A)
private val Blue = Color(0xFF2686C9)
private val Green = Color(0xFF19A66A)
private val Pale = Color(0xFFF3FAFE)

private fun tr(lang: String, en: String, it: String, de: String, fr: String, es: String): String = when (lang) {
    "it" -> it; "de" -> de; "fr" -> fr; "es" -> es; else -> en
}

private data class FaceLightingStats(val mean: Double, val lowerQuartile: Double, val shadowFraction: Double)

private data class PhotoCandidate(
    val uri: Uri, val score: Int, val sharpness: Double, val brightness: Double,
    val faceCount: Int, val openEyes: Int, val timestampMs: Long?, val sceneHash: Long,
    val faceCenters: List<Pair<Float, Float>>, val technicalRejected: Boolean, val explanation: String
)

private data class PhotoScore(
    val uri: Uri, val score: Int, val faceCount: Int, val openEyes: Int,
    val groupNumber: Int, val groupMembers: List<Uri>, val explanation: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoBestSelectorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoBestSelectorApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("photo_best_selector", android.content.Context.MODE_PRIVATE) }
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var results by remember { mutableStateOf<List<PhotoScore>>(emptyList()) }
    var status by remember { mutableStateOf("Choose photos from your gallery to find photo sequences.") }
    var analyzing by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("en") }
    var languageMenu by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var startDate by remember { mutableStateOf<Long?>(null) }
    var endDate by remember { mutableStateOf<Long?>(null) }
    var showStartDatePicker by remember { mutableStateOf(false) }
    var showEndDatePicker by remember { mutableStateOf(false) }
    var pendingAllPhotos by remember { mutableStateOf(false) }
    var viewerUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var viewerIndex by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        language = prefs.getString("language", "en") ?: "en"
        favorites = prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
    }

    val readPermission = if (android.os.Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && pendingAllPhotos) {
            pendingAllPhotos = false
            scope.launch {
                val loaded = withContext(Dispatchers.IO) { loadAllPhotos(context, startDate, endDate) }
                photos = loaded
                results = emptyList()
                status = if (loaded.isNotEmpty()) "${loaded.size} photos available for sequence analysis." else tr(language,"No photos found for this date range.","Nessuna foto trovata per questo intervallo.","Keine Fotos für diesen Zeitraum gefunden.","Aucune photo trouvée pour cette période.","No se encontraron fotos en este periodo.")
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(200)) { uris ->
        photos = uris
        results = emptyList()
        status = if (uris.isNotEmpty()) "${uris.size} photos selected. Only valid sequences will be considered." else tr(language,"No photos selected.","Nessuna foto selezionata.","Keine Fotos ausgewählt.","Aucune photo sélectionnée.","No se seleccionaron fotos.")
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Green, background = Pale, surface = Color.White, onSurface = Ink)) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = { Column { Text("PhotoBestSelector", fontWeight = FontWeight.Bold, color = Ink); Text("Find Your Perfect Shot.", fontSize = 12.sp, color = Blue) } },
                    actions = {
                        Box {
                            TextButton(onClick = { languageMenu = true }) { Text(language.uppercase(), color = Ink, fontWeight = FontWeight.Bold) }
                            DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                                listOf("en" to "English", "it" to "Italiano", "de" to "Deutsch", "fr" to "Français", "es" to "Español").forEach { (code,label) ->
                                    DropdownMenuItem(text={Text(label)}, onClick={ language=code; prefs.edit().putString("language",code).apply(); languageMenu=false })
                                }
                            }
                        }
                    }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Spacer(Modifier.height(12.dp))
                Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFE1F2FB)), shape=RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                        Text("📸", fontSize=40.sp)
                        Text(tr(language,"Find the best photo from each sequence.","Trova la foto migliore di ogni sequenza.","Finde das beste Foto jeder Serie.","Trouvez la meilleure photo de chaque séquence.","Encuentra la mejor foto de cada secuencia."), color=Ink, fontWeight=FontWeight.Bold)
                        Text(tr(language,"Only sequences of at least 2 photos, same situation, within 60 seconds.","Solo sequenze di almeno 2 foto, stessa situazione, entro 60 secondi.","Nur Serien mit mindestens 2 Fotos, gleicher Situation, innerhalb von 60 Sekunden.","Uniquement des séquences d'au moins 2 photos, même situation, dans les 60 secondes.","Solo secuencias de al menos 2 fotos, misma situación, dentro de 60 segundos."), color=Ink.copy(alpha=.72f), fontSize=12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(onClick={picker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))}, Modifier.fillMaxWidth().height(52.dp), shape=RoundedCornerShape(16.dp), colors=ButtonDefaults.buttonColors(containerColor=Blue)) {
                    Text(tr(language,"CHOOSE PHOTOS","SCEGLI FOTO","FOTOS AUSWÄHLEN","CHOISIR DES PHOTOS","ELEGIR FOTOS"), fontWeight=FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick={
                    pendingAllPhotos=true
                    if(ContextCompat.checkSelfPermission(context,readPermission)==PackageManager.PERMISSION_GRANTED){
                        pendingAllPhotos=false
                        scope.launch{ val loaded=withContext(Dispatchers.IO){loadAllPhotos(context,startDate,endDate)}; photos=loaded; results=emptyList(); status="${loaded.size} photos available for sequence analysis." }
                    } else permissionLauncher.launch(readPermission)
                }, Modifier.fillMaxWidth().height(50.dp), shape=RoundedCornerShape(16.dp)) { Text(tr(language,"SELECT ALL PHOTOS","SELEZIONA TUTTE LE FOTO","ALLE FOTOS AUSWÄHLEN","SÉLECTIONNER TOUTES LES PHOTOS","SELECCIONAR TODAS LAS FOTOS"), fontWeight=FontWeight.Bold) }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick={showStartDatePicker=true}, Modifier.weight(1f), shape=RoundedCornerShape(14.dp)){Text(startDate?.let(::formatDate)?:tr(language,"FROM DATE","DATA INIZIO","STARTDATUM","DATE DE DÉBUT","FECHA INICIO"),fontSize=11.sp)}
                    OutlinedButton(onClick={showEndDatePicker=true}, Modifier.weight(1f), shape=RoundedCornerShape(14.dp)){Text(endDate?.let(::formatDate)?:tr(language,"TO DATE","DATA FINE","ENDDATUM","DATE DE FIN","FECHA FIN"),fontSize=11.sp)}
                }
                if(startDate!=null||endDate!=null) TextButton(onClick={startDate=null;endDate=null}){Text(tr(language,"CLEAR DATE FILTER","CANCELLA FILTRO DATA","DATUMSFILTER LÖSCHEN","EFFACER LE FILTRE DE DATE","BORRAR FILTRO DE FECHA"),color=Blue,fontSize=11.sp)}

                if(photos.isNotEmpty()){
                    Spacer(Modifier.height(8.dp))
                    Text("${photos.size} ${tr(language,"photos selected","foto selezionate","Fotos ausgewählt","photos sélectionnées","fotos seleccionadas")}",color=Green,fontWeight=FontWeight.Bold)
                    LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        items(photos){uri->AsyncImage(model=uri,contentDescription=null,modifier=Modifier.size(66.dp).clip(RoundedCornerShape(8.dp)),contentScale=ContentScale.Crop)}
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(enabled=!analyzing,onClick={
                        analyzing=true; results=emptyList(); status=tr(language,"Finding valid photo sequences...","Ricerca delle sequenze valide...","Gültige Fotoserien werden gesucht...","Recherche des séquences valides...","Buscando secuencias de fotos válidas...")
                        scope.launch{try{val scored=withContext(Dispatchers.IO){analyzePhotos(context,photos)};results=scored;status=if(scored.isEmpty())tr(language,"No valid photo sequences found.","Nessuna sequenza valida trovata.","Keine gültige Fotoserie gefunden.","Aucune séquence valide trouvée.","No se encontraron secuencias válidas.") else "${scored.size} ${tr(language,"sequences found","sequenze trovate","Serien gefunden","séquences trouvées","secuencias encontradas")}"}catch(_:Exception){status=tr(language,"Analysis failed. Please try again.","Analisi non riuscita. Riprova.","Analyse fehlgeschlagen. Bitte erneut versuchen.","Échec de l'analyse. Réessayez.","El análisis falló. Inténtalo de nuevo.")}finally{analyzing=false}}
                    },Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                        if(analyzing)CircularProgressIndicator(Modifier.size(21.dp),color=Color.White,strokeWidth=2.dp) else Text(tr(language,"START ANALYSIS","AVVIA ANALISI","ANALYSE STARTEN","LANCER L'ANALYSE","INICIAR ANÁLISIS"),fontWeight=FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp)); Text(status,color=Ink.copy(alpha=.72f),fontSize=12.sp)

                if(results.isNotEmpty()){
                    Spacer(Modifier.height(16.dp))
                    Text(tr(language,"ONE WINNER PER SEQUENCE","UNA FOTO VINCITRICE PER SEQUENZA","EIN GEWINNER PRO SERIE","UNE PHOTO GAGNANTE PAR SÉQUENCE","UNA FOTO GANADORA POR SECUENCIA"),color=Ink,fontWeight=FontWeight.Bold,fontSize=14.sp)
                    results.forEach { item ->
                        val key=item.uri.toString(); val fav=favorites.contains(key)
                        Card(Modifier.fillMaxWidth().padding(vertical=6.dp),shape=RoundedCornerShape(16.dp),border=BorderStroke(2.dp,Green),colors=CardDefaults.cardColors(containerColor=Color.White)){
                            Column(Modifier.fillMaxWidth().padding(10.dp)){
                                Text("${tr(language,"Sequence","Sequenza","Serie","Séquence","Secuencia")} ${item.groupNumber} • ${item.groupMembers.size} ${tr(language,"photos","foto","Fotos","photos","fotos")}",color=Blue,fontWeight=FontWeight.Bold,fontSize=12.sp)
                                AsyncImage(model=item.uri,contentDescription=null,modifier=Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(12.dp)).clickable{viewerUris=item.groupMembers;viewerIndex=item.groupMembers.indexOf(item.uri).coerceAtLeast(0)},contentScale=ContentScale.Fit)
                                Spacer(Modifier.height(6.dp))
                                Row(verticalAlignment=Alignment.CenterVertically){
                                    Text(tr(language,"WINNER","VINCITRICE","GEWINNER","GAGNANTE","GANADORA"),color=Green,fontWeight=FontWeight.ExtraBold,fontSize=13.sp,modifier=Modifier.weight(1f))
                                    IconButton(onClick={favorites=if(fav)favorites-key else favorites+key;prefs.edit().putStringSet("favorites",favorites).apply()}){Icon(if(fav)Icons.Default.Star else Icons.Default.StarBorder,contentDescription=null,tint=if(fav)Color(0xFFE0A000) else Ink)}
                                }
                                Text(tr(language,"Why this photo?","Perché questa foto?","Warum dieses Foto?","Pourquoi cette photo ?","¿Por qué esta foto?"),color=Ink,fontWeight=FontWeight.Bold,fontSize=12.sp)
                                Text(item.explanation,color=Ink.copy(alpha=.78f),fontSize=11.sp,lineHeight=15.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(tr(language,"Tap the winner to compare all photos in this sequence.","Tocca la vincitrice per confrontare tutte le foto della sequenza.","Tippe auf den Gewinner, um alle Fotos dieser Serie zu vergleichen.","Touchez la gagnante pour comparer toutes les photos de la séquence.","Toca la ganadora para comparar todas las fotos de la secuencia."),color=Blue,fontSize=10.sp)
                                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                                    item.groupMembers.forEachIndexed { idx,uri->AsyncImage(model=uri,contentDescription=null,modifier=Modifier.size(58.dp).clip(RoundedCornerShape(7.dp)).clickable{viewerUris=item.groupMembers;viewerIndex=idx}.clip(RoundedCornerShape(7.dp)),contentScale=ContentScale.Crop) }
                                }
                                Spacer(Modifier.height(4.dp))
                                Button(onClick={viewerUris=item.groupMembers;viewerIndex=item.groupMembers.indexOf(item.uri).coerceAtLeast(0)},modifier=Modifier.fillMaxWidth().height(42.dp),shape=RoundedCornerShape(12.dp)){Text(tr(language,"OPEN & COMPARE","APRI E CONFRONTA","ÖFFNEN & VERGLEICHEN","OUVRIR & COMPARER","ABRIR Y COMPARAR"))}
                            }
                        }
                    }
                    Text(tr(language,"Single photos and unrelated scenes are excluded from the results. Originals are never deleted.","Le foto singole e le scene non correlate sono escluse dai risultati. Gli originali non vengono mai eliminati.","Einzelfotos und nicht zusammengehörige Szenen werden aus den Ergebnissen ausgeschlossen. Originale werden nie gelöscht.","Les photos isolées et les scènes différentes sont exclues des résultats. Les originaux ne sont jamais supprimés.","Las fotos individuales y las escenas diferentes se excluyen de los resultados. Los originales nunca se eliminan."),color=Ink.copy(alpha=.6f),fontSize=11.sp,lineHeight=15.sp)
                }
                Spacer(Modifier.height(20.dp))
            }
        }

        if(showStartDatePicker){val state=rememberDatePickerState(initialSelectedDateMillis=startDate?:System.currentTimeMillis());DatePickerDialog(onDismissRequest={showStartDatePicker=false},confirmButton={TextButton(onClick={startDate=startOfDay(state.selectedDateMillis);if(endDate!=null&&startDate!!>endDate!!)endDate=null;showStartDatePicker=false}){Text("OK")}},dismissButton={TextButton(onClick={showStartDatePicker=false}){Text(tr(language,"CANCEL","ANNULLA","ABBRECHEN","ANNULER","CANCELAR"))}}){DatePicker(state)}}
        if(showEndDatePicker){val state=rememberDatePickerState(initialSelectedDateMillis=endDate?:System.currentTimeMillis());DatePickerDialog(onDismissRequest={showEndDatePicker=false},confirmButton={TextButton(onClick={endDate=endOfDay(state.selectedDateMillis);if(startDate!=null&&endDate!!<startDate!!)startDate=null;showEndDatePicker=false}){Text("OK")}},dismissButton={TextButton(onClick={showEndDatePicker=false}){Text(tr(language,"CANCEL","ANNULLA","ABBRECHEN","ANNULER","CANCELAR"))}}){DatePicker(state)}}

        if(viewerUris.isNotEmpty()){
            FullscreenViewer(language,viewerUris,viewerIndex,onIndexChange={viewerIndex=it},onClose={viewerUris=emptyList()})
        }
    }
}

@Composable
private fun FullscreenViewer(language:String,uris:List<Uri>,initialIndex:Int,onIndexChange:(Int)->Unit,onClose:()->Unit){
    var index by remember(uris,initialIndex){mutableStateOf(initialIndex.coerceIn(0,uris.lastIndex))}
    var scale by remember(uris,index){mutableStateOf(1f)}
    var offset by remember(uris,index){mutableStateOf(Offset.Zero)}
    Dialog(onDismissRequest=onClose,properties=DialogProperties(usePlatformDefaultWidth=false)){
        Box(Modifier.fillMaxSize().background(Color.Black)){
            AsyncImage(model=uris[index],contentDescription=null,contentScale=ContentScale.Fit,modifier=Modifier.fillMaxSize().graphicsLayer(scaleX=scale,scaleY=scale,translationX=offset.x,translationY=offset.y).pointerInput(index){detectTransformGestures{_,pan,zoom,_->scale=(scale*zoom).coerceIn(1f,5f);offset=if(scale>1f)offset+pan else Offset.Zero}}.pointerInput(index){detectHorizontalDragGestures{_,drag->if(scale<=1.05f&&abs(drag)>90){if(drag<0&&index<uris.lastIndex)index++;else if(drag>0&&index>0)index--;onIndexChange(index);scale=1f;offset=Offset.Zero}}})
            IconButton(onClick=onClose,modifier=Modifier.align(Alignment.TopEnd).padding(12.dp)){Text("✕",color=Color.White,fontSize=26.sp)}
            if(index>0)IconButton(onClick={index--;onIndexChange(index);scale=1f;offset=Offset.Zero},modifier=Modifier.align(Alignment.CenterStart).padding(8.dp)){Icon(Icons.Default.ArrowBack,contentDescription=null,tint=Color.White,modifier=Modifier.size(40.dp))}
            if(index<uris.lastIndex)IconButton(onClick={index++;onIndexChange(index);scale=1f;offset=Offset.Zero},modifier=Modifier.align(Alignment.CenterEnd).padding(8.dp)){Icon(Icons.Default.ArrowForward,contentDescription=null,tint=Color.White,modifier=Modifier.size(40.dp))}
            Text("${index+1} / ${uris.size}",color=Color.White,fontSize=12.sp,modifier=Modifier.align(Alignment.BottomCenter).padding(bottom=18.dp))
        }
    }
}

private fun startOfDay(millis:Long?):Long?=millis?.let{Calendar.getInstance().apply{timeInMillis=it;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis}
private fun endOfDay(millis:Long?):Long?=millis?.let{Calendar.getInstance().apply{timeInMillis=it;set(Calendar.HOUR_OF_DAY,23);set(Calendar.MINUTE,59);set(Calendar.SECOND,59);set(Calendar.MILLISECOND,999)}.timeInMillis}
private fun formatDate(millis:Long):String=SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(java.util.Date(millis))

private fun loadAllPhotos(context:android.content.Context,startDate:Long?,endDate:Long?):List<Uri>{
    val c=MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val projection=arrayOf(MediaStore.Images.Media._ID,MediaStore.Images.Media.DATE_TAKEN,MediaStore.Images.Media.DATE_ADDED)
    val out=mutableListOf<Pair<Long,Uri>>()
    context.contentResolver.query(c,projection,null,null,MediaStore.Images.Media.DATE_TAKEN+" DESC")?.use{cur->
        val id=cur.getColumnIndexOrThrow(MediaStore.Images.Media._ID);val taken=cur.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN);val added=cur.getColumnIndex(MediaStore.Images.Media.DATE_ADDED)
        while(cur.moveToNext()){
            val mediaId=cur.getLong(id);val t=if(taken>=0&&!cur.isNull(taken))cur.getLong(taken) else 0L;val a=if(added>=0&&!cur.isNull(added))cur.getLong(added)*1000L else 0L;val ts=if(t>0)t else a
            if((startDate==null||ts>=startDate)&&(endDate==null||ts<=endDate))out.add(ts to Uri.withAppendedPath(c,mediaId.toString()))
        }
    }
    return out.sortedBy{it.first}.map{it.second}
}

private fun analyzePhotos(context:android.content.Context,uris:List<Uri>):List<PhotoScore>{
    val detector=FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build())
    try{
        val candidates=uris.mapNotNull{uri->
            val bitmap=loadBitmap(context.contentResolver.openInputStream(uri))?:return@mapNotNull null
            try{
                val faces=Tasks.await(detector.process(InputImage.fromBitmap(bitmap,0)))
                val sharp=calculateSharpness(bitmap);val bright=calculateBrightness(bitmap);val clipped=calculateClippedFraction(bitmap)
                val faceScores=faces.map{face->
                    val box=face.boundingBox;val px=(box.width()*.12f).toInt();val py=(box.height()*.12f).toInt();val l=(box.left-px).coerceIn(0,bitmap.width-1);val t=(box.top-py).coerceIn(0,bitmap.height-1);val r=(box.right+px).coerceIn(l+1,bitmap.width);val b=(box.bottom+py).coerceIn(t+1,bitmap.height);val crop=Bitmap.createBitmap(bitmap,l,t,r-l,b-t);val light=calculateFaceLighting(crop);val fs=calculateSharpness(crop);crop.recycle()
                    val le=face.leftEyeOpenProbability;val re=face.rightEyeOpenProbability;val eye=if(le==null&&re==null)65.0 else if(le!=null&&re!=null)(minOf(le,re)*100).coerceIn(0f,100f).toDouble() else ((le?:re?:.5f)*85).toDouble();val lightScore=(((light.mean-.16)/.34*100).coerceIn(0.0,100.0)*.45+((light.lowerQuartile-.10)/.30*100).coerceIn(0.0,100.0)*.30+(100-light.shadowFraction*190).coerceIn(0.0,100.0)*.25);val sharpFace=(sqrt(fs.coerceAtLeast(0.0))/12*100).coerceIn(0.0,100.0);val smile=face.smilingProbability;val expr=if(smile==null)75.0 else 75.0+smile*25.0;eye*.35+lightScore*.35+sharpFace*.20+expr*.10
                }
                val open=faces.count{((it.leftEyeOpenProbability?:.5f)>=.45f&& (it.rightEyeOpenProbability?:.5f)>=.45f)}
                val globalSharp=(sqrt(sharp.coerceAtLeast(0.0))/18*100).coerceIn(0.0,100.0);val globalLight=(100-abs(bright-.52)*150).coerceIn(0.0,100.0);val exposure=when{bright<.075||bright>.94->28.0;bright<.12||bright>.88->16.0;else->0.0}+(clipped*55).coerceAtMost(22.0);val blur=if(globalSharp<18)24.0 else if(globalSharp<30)12.0 else 0.0;val closed=faces.count{val l=it.leftEyeOpenProbability;val r=it.rightEyeOpenProbability;l!=null&&r!=null&&l<.22f&&r<.22f};val rejected=globalSharp<12||bright<.045||bright>.97||(clipped>.48&&(bright<.12||bright>.88))||(faces.isNotEmpty()&&closed==faces.size)
                val overall=if(faceScores.isEmpty())(globalSharp*.55+globalLight*.45-exposure-blur-if(rejected)35 else 0).coerceIn(0.0,100.0) else {val avg=faceScores.average();val weak=faceScores.minOrNull()?:avg;val group=avg*.5+weak*.5;val penalty=if(weak<30)(30-weak)*.9 else if(weak<50)(50-weak)*.45 else 0.0;(globalSharp*.1+globalLight*.05+group*.85-penalty-exposure-blur-if(rejected)35 else 0).coerceIn(0.0,100.0)}
                val details=buildList{add(if(faces.isEmpty())"No faces detected" else "$open/${faces.size} faces with open/uncertain eyes");add(if(globalSharp>=60)"good sharpness" else "limited sharpness");if(faceScores.isNotEmpty()&&(faceScores.minOrNull()?:100.0)<55)add("one face has weaker focus, light or eyes");add(if(globalLight>=60)"balanced light" else "challenging light");if(exposure>12)add("exposure/clipping warning");if(blur>0)add("possible blur");if(rejected)add("strong technical warning")}.joinToString(" • ")
                PhotoCandidate(uri,overall.toInt().coerceIn(0,100),sharp,bright,faces.size,open,readCaptureTime(context,uri),calculateSceneHash(bitmap),faces.map{Pair(it.boundingBox.centerX().toFloat()/bitmap.width,it.boundingBox.centerY().toFloat()/bitmap.height)}.sortedBy{it.first},rejected,details)
            }finally{bitmap.recycle()}
        }
        val sorted=candidates.sortedBy{it.timestampMs?:Long.MAX_VALUE};val groups=mutableListOf<MutableList<PhotoCandidate>>()
        for(c in sorted){val time=c.timestampMs;val match=if(time==null)null else groups.firstOrNull{g->val first=g.first();val ft=first.timestampMs;ft!=null&&time-ft<=60_000L&&first.faceCount==c.faceCount&&java.lang.Long.bitCount(first.sceneHash xor c.sceneHash)<=18&&similarFaceLayout(first.faceCenters,c.faceCenters)};if(match!=null)match.add(c) else groups.add(mutableListOf(c))}
        return groups.filter{it.size>=2}.mapIndexed{gi,g->val ranked=g.sortedWith(compareBy<PhotoCandidate>{it.technicalRejected}.thenByDescending{it.score});val w=ranked.firstOrNull{!it.technicalRejected}?:ranked.first();PhotoScore(w.uri,w.score,w.faceCount,w.openEyes,gi+1,ranked.map{it.uri},w.explanation)}
    }finally{detector.close()}
}

private fun readCaptureTime(context: android.content.Context, uri: Uri): Long? {
    val mediaStoreTime = try {
        context.contentResolver.query(uri, arrayOf(MediaStore.Images.Media.DATE_TAKEN), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
                if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index).takeIf { it > 0L } else null
            } else null
        }
    } catch (_: Exception) { null }
    if (mediaStoreTime != null) return mediaStoreTime
    return try {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val exif = ExifInterface(stream)
            val date = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) ?: return@use null
            val offset = exif.getAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL)
            val parser = if (!offset.isNullOrBlank()) SimpleDateFormat("yyyy:MM:dd HH:mm:ssXXX", Locale.US)
                else SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
            parser.parse(if (!offset.isNullOrBlank()) date + offset else date)?.time
        }
    } catch (_: Exception) { null }
}

private fun similarFaceLayout(a: List<Pair<Float, Float>>, b: List<Pair<Float, Float>>): Boolean {
    if (a.size != b.size) return false
    if (a.isEmpty()) return true
    return a.zip(b).all { (left, right) ->
        val dx = left.first - right.first
        val dy = left.second - right.second
        dx * dx + dy * dy <= 0.18f * 0.18f
    }
}

private fun calculateSceneHash(bitmap: Bitmap): Long {
    val sample = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
    val gray = IntArray(9 * 8)
    for (y in 0 until 8) for (x in 0 until 9) {
        val p = sample.getPixel(x, y)
        val r = (p shr 16 and 0xff)
        val g = (p shr 8 and 0xff)
        val b = (p and 0xff)
        gray[y * 9 + x] = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
    }
    sample.recycle()
    var hash = 0L
    var bit = 0
    for (y in 0 until 8) for (x in 0 until 8) {
        if (gray[y * 9 + x] > gray[y * 9 + x + 1]) hash = hash or (1L shl bit)
        bit++
    }
    return hash
}

private fun loadBitmap(stream: InputStream?): Bitmap? {
    if (stream == null) return null
    return stream.use { input ->
        val bytes = input.readBytes()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }
}


private fun calculateFaceLighting(bitmap: Bitmap): FaceLightingStats {
    // Ignore a narrow border around the detector box, where hair and background can distort
    // the measurement. Sample the central face area and inspect its darker quarter as well.
    val left = (bitmap.width * 0.12f).toInt().coerceIn(0, bitmap.width - 1)
    val top = (bitmap.height * 0.12f).toInt().coerceIn(0, bitmap.height - 1)
    val right = (bitmap.width * 0.88f).toInt().coerceIn(left + 1, bitmap.width)
    val bottom = (bitmap.height * 0.88f).toInt().coerceIn(top + 1, bitmap.height)
    val stepX = ((right - left) / 48).coerceAtLeast(1)
    val stepY = ((bottom - top) / 48).coerceAtLeast(1)
    val samples = ArrayList<Double>()
    for (y in top until bottom step stepY) {
        for (x in left until right step stepX) {
            val p = bitmap.getPixel(x, y)
            val r = (p shr 16 and 0xff) / 255.0
            val g = (p shr 8 and 0xff) / 255.0
            val b = (p and 0xff) / 255.0
            samples.add(0.2126 * r + 0.7152 * g + 0.0722 * b)
        }
    }
    if (samples.isEmpty()) return FaceLightingStats(0.5, 0.35, 0.0)
    samples.sort()
    val mean = samples.average()
    val lowerQuartile = samples[(samples.size * 0.25).toInt().coerceIn(0, samples.lastIndex)]
    val shadowFraction = samples.count { it < 0.18 }.toDouble() / samples.size
    return FaceLightingStats(mean, lowerQuartile, shadowFraction)
}

private fun calculateClippedFraction(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 100).coerceAtLeast(1)
    val stepY = (bitmap.height / 100).coerceAtLeast(1)
    var clipped = 0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16) and 0xff
            val g = (pixel shr 8) and 0xff
            val b = pixel and 0xff
            val luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
            if (luminance < 12.0 || luminance > 248.0) clipped++
            count++
        }
    }
    return if (count == 0) 0.0 else clipped.toDouble() / count
}

private fun calculateBrightness(bitmap: Bitmap): Double {
    val stepX = (bitmap.width / 80).coerceAtLeast(1)
    val stepY = (bitmap.height / 80).coerceAtLeast(1)
    var sum = 0.0
    var count = 0
    for (y in 0 until bitmap.height step stepY) {
        for (x in 0 until bitmap.width step stepX) {
            val pixel = bitmap.getPixel(x, y)
            val r = (pixel shr 16 and 0xff) / 255.0
            val g = (pixel shr 8 and 0xff) / 255.0
            val b = (pixel and 0xff) / 255.0
            sum += 0.2126 * r + 0.7152 * g + 0.0722 * b
            count++
        }
    }
    return if (count == 0) 0.5 else sum / count
}

private fun calculateSharpness(bitmap: Bitmap): Double {
    val scale = minOf(1.0, 240.0 / maxOf(bitmap.width, bitmap.height))
    val w = (bitmap.width * scale).toInt().coerceAtLeast(3)
    val h = (bitmap.height * scale).toInt().coerceAtLeast(3)
    val small = Bitmap.createScaledBitmap(bitmap, w, h, true)
    val values = DoubleArray(w * h)
    for (y in 0 until h) for (x in 0 until w) {
        val p = small.getPixel(x, y)
        val r = (p shr 16 and 0xff).toDouble()
        val g = (p shr 8 and 0xff).toDouble()
        val b = (p and 0xff).toDouble()
        values[y * w + x] = 0.299 * r + 0.587 * g + 0.114 * b
    }
    var sum = 0.0
    var sumSq = 0.0
    var count = 0
    for (y in 1 until h - 1) for (x in 1 until w - 1) {
        val i = y * w + x
        val lap = values[i - w] + values[i - 1] - 4 * values[i] + values[i + 1] + values[i + w]
        sum += lap
        sumSq += lap * lap
        count++
    }
    small.recycle()
    if (count == 0) return 0.0
    val mean = sum / count
    return (sumSq / count - mean * mean).coerceAtLeast(0.0)
}

@Composable
private fun ChoiceCard(
    title: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    selected: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) Blue else Color(0xFFDCEAF2)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFEAF6FC), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Ink.copy(alpha = .62f), fontSize = 11.sp)
            }
            RadioButton(selected = selected, onClick = onClick)
        }
    }
}
